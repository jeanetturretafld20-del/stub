#!/bin/sh
set -eu
cd /workspace
node scripts/preview.mjs stop || true
if ! curl -sf -o /dev/null --max-time 2 http://127.0.0.1:8080/; then
  npm run dev >>/tmp/app-startup.log 2>&1 &
fi
# The tape starts with the process, not with a visitor. Do not block revive on it.
(
  i=0
  while [ "$i" -lt 40 ]; do
    if curl -sf -o /dev/null --max-time 8 http://127.0.0.1:8080/api/tape; then
      exit 0
    fi
    i=$((i + 1))
    sleep 0.5
  done
) >>/tmp/tape-boot.log 2>&1 &
