/** Address clients send funds to. The desk does not read this wallet. */
export const FUNDING_WALLET = "0xC60F123453D393f8F1D98f095027a6e497f5Cd36";
