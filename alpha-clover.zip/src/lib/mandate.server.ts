import { getSql } from "@/lib/db";
import { CONTRACT_MONTHS, MANDATE_CAPITAL, contractEnd, feeOn } from "@/lib/mandate";

type Row = {
  user_id: string;
  capital_usd: number;
  opened_at: string;
  contract_ends_at: string;
  status: string;
  pending_profit: number;
  pending_fee: number;
  withdrawn_profit: number;
  fees_paid: number;
};

async function db() {
  return getSql();
}

function view(row: Row) {
  const ends = new Date(row.contract_ends_at);
  const locked = Date.now() < ends.getTime();
  const pendingProfit = Number(row.pending_profit) || 0;
  const pendingFee = Number(row.pending_fee) || 0;
  return {
    capital: Number(row.capital_usd) || 0,
    contractEnds: ends.toISOString(),
    locked,
    status: row.status === "fee_due" ? "fee_due" : "idle",
    pendingProfit,
    pendingFee,
    pendingNet: Math.round((pendingProfit - pendingFee) * 100) / 100,
    withdrawn: Number(row.withdrawn_profit) || 0,
    feesPaid: Number(row.fees_paid) || 0,
    feeRate: 0.2,
    contractMonths: CONTRACT_MONTHS,
  };
}

export async function getMandate(userId: string, openedAt: Date) {
  const pg = await db();
  const found = await pg.query<Row>(`select * from mandate where user_id = $1`, [userId]);
  if (found[0]) return view(found[0]);
  const ends = contractEnd(openedAt);
  await pg.query(
    `insert into mandate (user_id, capital_usd, opened_at, contract_ends_at)
     values ($1, $2, $3, $4)
     on conflict (user_id) do nothing`,
    [userId, MANDATE_CAPITAL, openedAt.toISOString(), ends.toISOString()],
  );
  const again = await pg.query<Row>(`select * from mandate where user_id = $1`, [userId]);
  const row = again[0];
  if (!row) throw new Error("The mandate was not opened.");
  return view(row);
}

export async function requestProfitWithdrawal(userId: string, openedAt: Date, amount: number, realized: number) {
  const current = await getMandate(userId, openedAt);
  const room = Math.max(0, (Number(realized) || 0) - current.withdrawn);
  if (!(amount > 0) || !Number.isFinite(amount)) {
    return { error: "Enter the profit to withdraw." as const };
  }
  if (amount > room + 0.001) {
    return { error: "There is no profit to withdraw. Capital is not profit." as const };
  }
  if (current.status === "fee_due") {
    return { error: "A broker fee is already due. Pay it before another withdrawal." as const };
  }
  const { fee, net } = feeOn(amount);
  if (!(fee > 0)) return { error: "The broker fee is due on any profit." as const };
  const pg = await db();
  await pg.query(
    `update mandate
     set status = 'fee_due', pending_profit = $2, pending_fee = $3, updated_at = now()
     where user_id = $1`,
    [userId, amount, fee],
  );
  const next = await getMandate(userId, openedAt);
  return { mandate: next, net };
}

export async function confirmFeePaid(userId: string, openedAt: Date) {
  const current = await getMandate(userId, openedAt);
  if (current.status !== "fee_due" || !(current.pendingFee > 0)) {
    return { error: "There is no broker fee to pay. The withdrawal has not started." as const };
  }
  const pg = await db();
  await pg.query(
    `update mandate
     set status = 'idle',
         withdrawn_profit = withdrawn_profit + pending_profit,
         fees_paid = fees_paid + pending_fee,
         pending_profit = 0,
         pending_fee = 0,
         updated_at = now()
     where user_id = $1 and status = 'fee_due'`,
    [userId],
  );
  return { mandate: await getMandate(userId, openedAt), released: current.pendingNet, fee: current.pendingFee };
}

export function capitalRefusal(endsIso: string) {
  return `Capital stays until the contract ends on ${new Date(endsIso).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}.`;
}
