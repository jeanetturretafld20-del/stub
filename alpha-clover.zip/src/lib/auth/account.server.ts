/** The signed-in account, or null. Cookies first, then the preview bearer token. */
export async function readAccount(headers: Headers) {
  const { auth } = await import("./server");
  const direct = await auth.api.getSession({ headers });
  if (direct?.user) return direct.user;
  const authz = headers.get("authorization") || headers.get("Authorization");
  if (!authz) return null;
  const res = await auth.handler(
    new Request("http://localhost/api/auth/get-session", { method: "GET", headers }),
  );
  if (!res.ok) return null;
  const body = (await res.json().catch(() => null)) as { user?: { id: string; name: string; email: string; createdAt?: string | Date } } | null;
  return body?.user ?? null;
}