import { createMiddleware, createServerFn } from "@tanstack/react-start";

const forwardSession = createMiddleware({ type: "function" }).client(async ({ next }) => {
  const { getBearerToken } = await import("./client");
  return next({ sendContext: { bearerToken: getBearerToken() ?? undefined } });
});

/** A real account. Never the shared dev user, and never an open page. */
export const accountOpen = createServerFn({ method: "GET" })
  .middleware([forwardSession])
  .handler(async ({ context }) => {
    const { getRequest } = await import("@tanstack/react-start/server");
    const { assertSameSiteRequest } = await import("./isolation.server");
    const { auth } = await import("./server");
    assertSameSiteRequest();
    const request = getRequest();
    if (!request) return { ok: false as const };
    const headers = new Headers(request.headers);
    const token = (context as { bearerToken?: string }).bearerToken;
    if (token) headers.set("Authorization", `Bearer ${token}`);
    const session = await auth.api.getSession({ headers });
    return { ok: Boolean(session?.user) as boolean };
  });

/** The public site, the operator desk, and the auth API. Client accounts stay closed. */
export function isPublicPath(pathname: string) {
  return pathname === "/" || pathname === "/desk" || pathname.startsWith("/api/auth");
}
