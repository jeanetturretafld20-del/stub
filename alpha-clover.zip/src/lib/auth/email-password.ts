/**
 * Local email/password sign-in (this app's own Better Auth DB — not the broker).
 *
 * Accounts stay closed until the person opens the confirmation link we email them.
 * The letter is sent from `/send-verification-email`, which reports a failure.
 * Sign-up itself must not send: Better Auth swallows that error and still
 * returns success, which would tell someone a letter left when it did not.
 * Do not edit `server.ts` beyond the spread of `emailAuthConfig`.
 */
export const emailAndPasswordEnabled = true;

type VerifyUser = { id: string; email: string; name?: string | null };
type ResetUser = { email: string; name?: string | null };

async function refuse(err: unknown) {
  const message = err instanceof Error ? err.message : "send failed";
  console.error("[verify-mail]", message.replace(/https?:\/\/\S+/g, "[link]").replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "[mailbox]"));
  const { APIError } = await import("@better-auth/core/error");
  throw new APIError("INTERNAL_SERVER_ERROR", {
    message: "The letter could not be sent.",
  });
}

export const emailAuthConfig = {
  emailAndPassword: {
    enabled: true,
    requireEmailVerification: true,
    resetPasswordTokenExpiresIn: 60 * 60,
    revokeSessionsOnPasswordReset: true,
    sendResetPassword: async ({ user, url }: { user: ResetUser; url: string }) => {
      const { deliverReset } = await import("../verify-mail.server");
      try {
        await deliverReset({ to: user.email, name: user.name || "", url });
      } catch (err) {
        await refuse(err);
      }
    },
  },
  emailVerification: {
    sendOnSignUp: false,
    sendOnSignIn: false,
    autoSignInAfterVerification: true,
    expiresIn: 60 * 60 * 24,
    sendVerificationEmail: async ({ user, url }: { user: { email: string; name?: string | null }; url: string }) => {
      const { deliverVerification } = await import("../verify-mail.server");
      try {
        await deliverVerification({ to: user.email, name: user.name || "", url });
      } catch (err) {
        await refuse(err);
      }
    },
    afterEmailVerification: async (user: VerifyUser) => {
      try {
        const { roleFor } = await import("../staff.server");
        const { listPost } = await import("../post.server");
        const role = await roleFor(user.id, user.email);
        await listPost(user.id, user.name || "", role === "admin");
      } catch (err) {
        console.error("[verify-mail]", err instanceof Error ? err.message : err);
      }
    },
  },
};
