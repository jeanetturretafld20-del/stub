import { SignJWT } from "jose";

export async function issueVerificationUrl(email: string, callbackURL: string) {
  const { auth } = await import("@/lib/auth/server");
  const ctx = await auth.$context;
  const found = await ctx.internalAdapter.findUserByEmail(email);
  if (!found?.user) {
    throw new Error("Open the account again. Nothing is waiting on that address.");
  }
  if (found.user.emailVerified) {
    throw new Error("That address is already confirmed. Sign in.");
  }
  const token = await new SignJWT({ email })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(Math.floor(Date.now() / 1000) + 60 * 60 * 24)
    .sign(new TextEncoder().encode(ctx.secret));
  const origin = new URL(callbackURL).origin;
  const url = `${origin}/api/auth/verify-email?token=${token}&callbackURL=${encodeURIComponent(callbackURL)}`;
  return { url, name: found.user.name || "" };
}
