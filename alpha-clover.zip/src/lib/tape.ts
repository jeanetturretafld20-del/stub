import { createServerFn } from "@tanstack/react-start";

/** Start the firm tape. Safe to call on every request; the clock keeps running after this returns. */
export const bootTape = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const { ensureTape } = await import("./tape.server");
    await ensureTape();
  } catch (err) {
    console.error("[tape]", err);
  }
  return { ok: true as const };
});
