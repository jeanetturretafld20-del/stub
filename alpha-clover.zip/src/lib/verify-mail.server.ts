import { AsyncLocalStorage } from "node:async_hooks";
import { callTool } from "@/lib/app-data/client.server";
import { ConnectorType } from "@/lib/app-data/types";
import { FIRM_EMAIL } from "@/lib/firm";

type Letter = {
  to: string;
  subject: string;
  text: string;
  html: string;
};

function escapeHtml(value: string) {
  return value
    .replace(/&/g, "\u0026amp;")
    .replace(/</g, "\u0026lt;")
    .replace(/>/g, "\u0026gt;")
    .replace(/"/g, "\u0026quot;");
}

function shell(title: string, body: string, action: string, url: string, footnote: string) {
  const href = escapeHtml(url);
  const from = escapeHtml(FIRM_EMAIL);
  return `<!doctype html>
<html>
<body style="margin:0;background:#f3f0e8;color:#171b18;font-family:Georgia,'Times New Roman',serif;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f0e8;">
    <tr><td align="center" style="padding:40px 16px;">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:520px;background:#ffffff;border:1px solid #e2dbcf;">
        <tr><td style="padding:36px 32px 8px;font-size:13px;letter-spacing:0.14em;text-transform:uppercase;color:#5c6560;font-family:'IBM Plex Sans',Helvetica,Arial,sans-serif;">Alpha Clover</td></tr>
        <tr><td style="padding:8px 32px 0;font-size:32px;line-height:1.15;">${escapeHtml(title)}</td></tr>
        <tr><td style="padding:18px 32px 0;font-size:16px;line-height:1.55;font-family:'IBM Plex Sans',Helvetica,Arial,sans-serif;color:#3e4742;">${body}</td></tr>
        <tr><td style="padding:28px 32px 8px;">
          <a href="${href}" style="display:inline-block;background:#171b18;color:#f3f0e8;text-decoration:none;font-family:'IBM Plex Sans',Helvetica,Arial,sans-serif;font-size:14px;padding:14px 22px;">${escapeHtml(action)}</a>
        </td></tr>
        <tr><td style="padding:8px 32px 16px;font-size:13px;line-height:1.5;font-family:'IBM Plex Sans',Helvetica,Arial,sans-serif;color:#5c6560;">Or copy this address into a browser:<br><a href="${href}" style="color:#1f6b4a;word-break:break-all;">${href}</a></td></tr>
        <tr><td style="padding:0 32px 32px;font-size:12px;line-height:1.5;font-family:'IBM Plex Sans',Helvetica,Arial,sans-serif;color:#8a8478;">Sent by Alpha Clover<br>${from}</td></tr>
      </table>
      <p style="max-width:520px;font-family:'IBM Plex Sans',Helvetica,Arial,sans-serif;font-size:12px;line-height:1.5;color:#8a8478;">${escapeHtml(footnote)}</p>
    </td></tr>
  </table>
</body>
</html>`;
}

function quiet(message: string) {
  return message.replace(/https?:\/\/\S+/g, "[link]").replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "[mailbox]");
}

function sign(lines: string[]) {
  return [...lines, "", "Alpha Clover", FIRM_EMAIL].join("\n");
}

async function sendViaResend(letter: Letter) {
  const key = process.env.RESEND_API_KEY;
  if (!key) return false;
  const from = process.env.MAIL_FROM || `Alpha Clover <${FIRM_EMAIL}>`;
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      authorization: `Bearer ${key}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({
      from,
      to: [letter.to],
      subject: letter.subject,
      html: letter.html,
      text: letter.text,
    }),
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    throw new Error(quiet(detail).slice(0, 180) || "The letter could not be sent.");
  }
  return true;
}

const mailboxToken = new AsyncLocalStorage<string | null>();

export function withMailboxToken<T>(token: string | null, run: () => Promise<T>) {
  return mailboxToken.run(token, run);
}

async function sendViaOutlook(letter: Letter) {
  // Preview hosts are *.grok-sandbox.com. The connector client only infers a
  // gate for *.grok.me unless this is set, so a granted mailbox never gets called.
  if (!process.env.GROK_CONNECTORS_URL) {
    process.env.GROK_CONNECTORS_URL = "https://connectors.grok.me";
  }
  const result = await callTool(
    "outlook_send_message",
    {
      to: [letter.to],
      subject: letter.subject,
      body: letter.text,
      body_html: letter.html,
    },
    { connectorType: ConnectorType.Outlook, token: mailboxToken.getStore() },
  );
  if (result.ok) return;
  throw new Error(quiet(result.errorMessage || "The letter could not be sent.").slice(0, 180));
}

async function deliver(letter: Letter) {
  if (await sendViaResend(letter)) return;
  await sendViaOutlook(letter);
}

/** Confirmation letter. Throws if it did not leave. */
export async function deliverVerification(input: { to: string; name: string; url: string }) {
  const who = escapeHtml(input.name.trim() || "Client");
  const text = sign([
    `${input.name.trim() || "Client"},`,
    "",
    "Confirm the account by opening the link below. The account stays closed until you do. The link expires in 24 hours.",
    "",
    input.url,
    "",
    "If you did not open an account, ignore this letter.",
  ]);
  await deliver({
    to: input.to,
    subject: "Confirm your Alpha Clover account",
    text,
    html: shell(
      "Confirm the account.",
      `${who}, open the link to verify the address. The account stays closed until you do. The link expires in 24 hours.`,
      "Confirm the account",
      input.url,
      "If you did not open an account, you can ignore this letter.",
    ),
  });
}

/** Password letter. Throws if it did not leave. */
export async function deliverReset(input: { to: string; name: string; url: string }) {
  const who = escapeHtml(input.name.trim() || "Client");
  const text = sign([
    `${input.name.trim() || "Client"},`,
    "",
    "Choose a new password by opening the link below. It expires in one hour.",
    "",
    input.url,
    "",
    "If you did not ask for this, ignore this letter. The password stays as it is.",
  ]);
  await deliver({
    to: input.to,
    subject: "Reset your Alpha Clover password",
    text,
    html: shell(
      "Reset the password.",
      `${who}, open the link to choose a new password. It expires in one hour.`,
      "Choose a new password",
      input.url,
      "If you did not ask for this, you can ignore this letter. The password stays as it is.",
    ),
  });
}
