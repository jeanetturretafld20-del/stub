export type AssetClass = "stock" | "crypto" | "fx";
export type Tf = "1m" | "5m" | "15m" | "1H" | "4H" | "1D";

export interface Instrument {
  symbol: string;
  name: string;
  klass: AssetClass;
  px: number;
  digits: number;
  vol: number;
}

export interface Bar {
  t: number;
  o: number;
  h: number;
  l: number;
  c: number;
  v: number;
}

export const TIMEFRAMES: Tf[] = ["1m", "5m", "15m", "1H", "4H", "1D"];

const TF_MS: Record<Tf, number> = {
  "1m": 60_000,
  "5m": 300_000,
  "15m": 900_000,
  "1H": 3_600_000,
  "4H": 14_400_000,
  "1D": 86_400_000,
};

export const INSTRUMENTS: Instrument[] = [
  { symbol: "AAPL", name: "Apple", klass: "stock", px: 228.4, digits: 2, vol: 0.004 },
  { symbol: "MSFT", name: "Microsoft", klass: "stock", px: 428.15, digits: 2, vol: 0.0036 },
  { symbol: "NVDA", name: "NVIDIA", klass: "stock", px: 138.6, digits: 2, vol: 0.008 },
  { symbol: "AMZN", name: "Amazon", klass: "stock", px: 197.8, digits: 2, vol: 0.0045 },
  { symbol: "GOOGL", name: "Alphabet", klass: "stock", px: 172.35, digits: 2, vol: 0.0042 },
  { symbol: "META", name: "Meta", klass: "stock", px: 582.1, digits: 2, vol: 0.0055 },
  { symbol: "TSLA", name: "Tesla", klass: "stock", px: 248.9, digits: 2, vol: 0.009 },
  { symbol: "JPM", name: "JPMorgan", klass: "stock", px: 224.7, digits: 2, vol: 0.0034 },
  { symbol: "XOM", name: "Exxon", klass: "stock", px: 118.2, digits: 2, vol: 0.0038 },
  { symbol: "LLY", name: "Eli Lilly", klass: "stock", px: 892.4, digits: 2, vol: 0.0048 },
  { symbol: "BTC", name: "Bitcoin", klass: "crypto", px: 82111, digits: 2, vol: 0.008 },
  { symbol: "ETH", name: "Ether", klass: "crypto", px: 3520, digits: 2, vol: 0.01 },
  { symbol: "SOL", name: "Solana", klass: "crypto", px: 178.4, digits: 2, vol: 0.014 },
  { symbol: "XRP", name: "XRP", klass: "crypto", px: 0.623, digits: 4, vol: 0.012 },
  { symbol: "EURUSD", name: "Euro", klass: "fx", px: 1.08642, digits: 5, vol: 0.0012 },
  { symbol: "GBPUSD", name: "Sterling", klass: "fx", px: 1.2938, digits: 5, vol: 0.0014 },
  { symbol: "USDJPY", name: "Yen", klass: "fx", px: 149.24, digits: 3, vol: 0.0013 },
  { symbol: "USDCHF", name: "Swiss", klass: "fx", px: 0.8641, digits: 5, vol: 0.0012 },
  { symbol: "AUDUSD", name: "Aussie", klass: "fx", px: 0.6624, digits: 5, vol: 0.0016 },
  { symbol: "USDCAD", name: "Loonie", klass: "fx", px: 1.3642, digits: 5, vol: 0.0013 },
];

export function instrument(symbol: string) {
  return INSTRUMENTS.find((i) => i.symbol === symbol) ?? INSTRUMENTS[0];
}

export function formatPx(n: number, digits: number) {
  return n.toLocaleString("en-US", { minimumFractionDigits: digits, maximumFractionDigits: digits });
}

export function formatDesk(n: number) {
  return n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function hash(text: string) {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 16777619);
  return h >>> 0;
}

function mulberry(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function buildBars(symbol: string, tf: Tf, count = 90): Bar[] {
  const spec = instrument(symbol);
  const rnd = mulberry(hash(`${symbol}:${tf}`));
  let px = spec.px * (0.985 + rnd() * 0.02);
  const step = TF_MS[tf];
  const start = Date.now() - (count - 1) * step;
  const bars: Bar[] = [];
  for (let i = 0; i < count; i++) {
    const shock = (rnd() - 0.48) * spec.vol * px;
    const o = px;
    const c = Math.max(spec.px * 0.4, o + shock);
    const wick = spec.vol * px * (0.15 + rnd() * 0.85);
    const h = Math.max(o, c) + wick * rnd();
    const l = Math.max(0.00001, Math.min(o, c) - wick * rnd());
    bars.push({ t: start + i * step, o, h, l, c, v: Math.round(400 + rnd() * 4600) });
    px = c;
  }
  return bars;
}

export function stepBars(bars: Bar[], symbol: string, at = Date.now()): Bar[] {
  if (bars.length === 0) return bars;
  const spec = instrument(symbol);
  const rnd = mulberry((hash(symbol) ^ Math.floor(at / 1000)) >>> 0);
  const next = bars.map((b) => ({ ...b }));
  const last = next[next.length - 1];
  const move = (rnd() - 0.5) * spec.vol * last.c * 0.35;
  last.c = Math.max(spec.px * 0.4, last.c + move);
  last.h = Math.max(last.h, last.c);
  last.l = Math.min(last.l, last.c);
  last.v += Math.round(20 + rnd() * 80);
  if (rnd() > 0.82) {
    const span = bars.length > 1 ? bars[1].t - bars[0].t : 60_000;
    next.push({ t: last.t + span, o: last.c, h: last.c, l: last.c, c: last.c, v: 80 });
    if (next.length > 110) next.shift();
  }
  return next;
}
