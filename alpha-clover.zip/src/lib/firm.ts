/** Official firm mailbox. Public. Letters leave from this address only. */
export const FIRM_EMAIL = "alphaclover07@outlook.com";
