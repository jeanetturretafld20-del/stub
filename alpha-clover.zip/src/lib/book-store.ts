import { authHeaders } from "@/lib/auth/client";
import type { OperatorState } from "@/lib/operator";

const TICK_MS = 1500;

export type TapeView = { book: OperatorState; behind: number };

/** The firm tape. The server keeps it moving; this only listens. */
export function subscribeBook(fn: (view: TapeView) => void) {
  let stop = false;
  async function pull() {
    try {
      const res = await fetch("/api/book", { headers: authHeaders() });
      if (!res.ok || stop) return;
      const body = (await res.json()) as TapeView;
      if (!stop && body?.book?.ledger) fn(body);
    } catch {
      /* the next pull retries */
    }
  }
  void pull();
  const id = window.setInterval(() => void pull(), TICK_MS);
  return () => {
    stop = true;
    window.clearInterval(id);
  };
}
