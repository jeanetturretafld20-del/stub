import { getSql } from "@/lib/db";

export type KycInput = {
  legalName: string;
  dateOfBirth: string;
  citizenship: string;
  residence: string;
  address: string;
  city: string;
  region: string;
  postal: string;
  phone: string;
  employment: string;
  source: string;
  taxId: string;
  taxKind: string;
  idType: string;
  idNumber: string;
  pep: boolean;
};

const EMPLOYMENT = ["employed", "self-employed", "retired", "student", "unemployed"];
const SOURCES = ["salary", "savings", "business", "investment", "other"];
const ID_TYPES = ["passport", "national", "driver"];
const TAX_KINDS = ["ssn", "tin"];

export function checkKyc(input: Partial<KycInput>): string | null {
  const name = input.legalName?.trim() ?? "";
  if (name.length < 2) return "The legal name is required.";
  const dob = input.dateOfBirth?.trim() ?? "";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dob)) return "The date of birth is required.";
  const born = new Date(`${dob}T00:00:00Z`);
  if (Number.isNaN(born.getTime())) return "The date of birth is required.";
  const adult = new Date();
  adult.setUTCFullYear(adult.getUTCFullYear() - 18);
  if (born > adult) return "The account holder must be 18 or older.";
  if ((input.citizenship?.trim().length ?? 0) < 2) return "Citizenship is required.";
  if ((input.residence?.trim().length ?? 0) < 2) return "Country of residence is required.";
  if ((input.address?.trim().length ?? 0) < 4) return "The street address is required.";
  if ((input.city?.trim().length ?? 0) < 2) return "The city is required.";
  if ((input.region?.trim().length ?? 0) < 2) return "The state or region is required.";
  if ((input.postal?.trim().length ?? 0) < 2) return "The postal code is required.";
  const phone = (input.phone ?? "").replace(/\D/g, "");
  if (phone.length < 7) return "A phone number is required.";
  if (!EMPLOYMENT.includes(input.employment ?? "")) return "Employment is required.";
  if (!SOURCES.includes(input.source ?? "")) return "The source of funds is required.";
  if (!ID_TYPES.includes(input.idType ?? "")) return "The ID type is required.";
  if ((input.idNumber?.trim().length ?? 0) < 4) return "The ID number is required.";
  if (!TAX_KINDS.includes(input.taxKind ?? "")) return "Choose SSN or tax ID. Not both.";
  const tax = (input.taxId ?? "").replace(/\s/g, "");
  if (input.taxKind === "ssn" && tax.replace(/\D/g, "").length !== 9) return "An SSN is nine digits.";
  if (input.taxKind === "tin" && tax.length < 4) return "The tax ID is required.";
  if (typeof input.pep !== "boolean") return "Say whether you are a politically exposed person.";
  return null;
}

export async function hasKyc(userId: string) {
  const sql = await getSql();
  const rows = await sql.query<{ ok: number }>(`select 1 as ok from kyc where user_id = $1`, [userId]);
  return rows.length > 0;
}

export async function fileKyc(userId: string, input: KycInput) {
  const problem = checkKyc(input);
  if (problem) throw new Error(problem);
  const sql = await getSql();
  await sql.query(
    `insert into kyc (
       user_id, legal_name, date_of_birth, citizenship, residence, address, city, region, postal,
       phone, employment, source_of_funds, tax_id, tax_kind, id_type, id_number, pep
     ) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)
     on conflict (user_id) do update set
       legal_name = excluded.legal_name,
       date_of_birth = excluded.date_of_birth,
       citizenship = excluded.citizenship,
       residence = excluded.residence,
       address = excluded.address,
       city = excluded.city,
       region = excluded.region,
       postal = excluded.postal,
       phone = excluded.phone,
       employment = excluded.employment,
       source_of_funds = excluded.source_of_funds,
       tax_id = excluded.tax_id,
       tax_kind = excluded.tax_kind,
       id_type = excluded.id_type,
       id_number = excluded.id_number,
       pep = excluded.pep,
       filed_at = now()`,
    [
      userId,
      input.legalName.trim(),
      input.dateOfBirth,
      input.citizenship.trim(),
      input.residence.trim(),
      input.address.trim(),
      input.city.trim(),
      input.region.trim(),
      input.postal.trim(),
      input.phone.trim(),
      input.employment,
      input.source,
      input.taxId.trim(),
      input.taxKind,
      input.idType,
      input.idNumber.trim(),
      input.pep,
    ],
  );
}
