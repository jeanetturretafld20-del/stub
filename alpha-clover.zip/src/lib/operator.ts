/** Alpha Clover 5.8 operator.
 *  v5.7 charter, unchanged: 1% learn risk, real sleeve capped at 15%,
 *  earned gate (20 bets, +0.15R, 40% win), 2.5×ATR stop cap, 3-session max hold,
 *  index pair lock, 10% drawdown halt. v5.8 runs that charter without a click.
 *  The tape is accelerated and synthetic so the machine can be watched. No broker.
 */

export type MarketId = "SP500" | "NDX100" | "BTC" | "ETH" | "GOLD" | "WTI";
export type Regime = "RANGE" | "TREND" | "VOL";
export type Feed = "LIVE" | "STALE" | "HEALING";
export type Side = "LONG" | "SHORT";
export type Sleeve = "LEARN" | "REAL";
export type FundAsset = "USDC" | "BTC";
export type FundStatus = "idle" | "watching" | "confirming" | "credited";

export function isCrypto(id: MarketId) {
  return id === "BTC" || id === "ETH";
}

export interface Market {
  id: MarketId;
  label: string;
  px: number;
  anchor: number;
  chg: number;
  atrPct: number;
  adx: number;
  regime: Regime;
  feed: Feed;
  session: boolean;
  london: boolean;
  spark: number[];
  /** Exchange print. Absent until a live quote arrives. Never a simulated price. */
  quote?: number;
  quoteSpark?: number[];
}

export interface Edge {
  id: string;
  market: MarketId;
  strategy: string;
  name: string;
  tf: string;
  thesis: string;
  settled: number;
  wins: number;
  totalR: number;
  earned: boolean;
  gen: number;
  gene: string;
  bias: number;
  targetR: number;
  maxBars: number;
  enabled: boolean;
  why: string;
  allocation: number;
}

export interface Position {
  id: string;
  edgeId: string;
  market: MarketId;
  name: string;
  side: Side;
  entry: number;
  stop: number;
  target: number;
  riskUsd: number;
  sleeve: Sleeve;
  bars: number;
  maxBars: number;
  unrealR: number;
  targetR: number;
}

export interface ClosedTrade {
  id: string;
  name: string;
  market: MarketId;
  side: Side;
  sleeve: Sleeve;
  r: number;
  pnl: number;
  reason: string;
  tick: number;
}

export interface MarketPnl {
  earned: number;
  lost: number;
}

export interface Funding {
  asset: FundAsset;
  network: string;
  amountUsd: number;
  confirmations: number;
  need: number;
  status: FundStatus;
  ref: string;
}

export interface LogItem {
  id: number;
  tick: number;
  kind: string;
  text: string;
}

export interface OperatorState {
  seed: number;
  tick: number;
  seq: number;
  bankroll: number;
  peak: number;
  halted: boolean;
  cool: number;
  realLock: number;
  cryptoBook: number;
  cryptoPeak: number;
  cryptoEquity: number[];
  cryptoHalted: boolean;
  cryptoCool: number;
  cryptoLock: number;
  funding: Funding;
  markets: Market[];
  edges: Edge[];
  positions: Position[];
  closed: ClosedTrade[];
  ledger: Record<MarketId, MarketPnl>;
  logs: LogItem[];
  equity: number[];
  returns: Record<MarketId, number[]>;
  clockMin: number;
  human: string;
  healed: number;
  skipped: number;
  fills: number;
}

const EARN_MIN_BETS = 20;
const EARN_MIN_EXP = 0.15;
const EARN_MIN_WIN = 0.4;
const REAL_CAP = 0.15;
const LEARN_RISK = 0.01;
const REAL_RISK = 0.01;
const CHALLENGER_RISK = 0.0025;
const DD_GUARD = 0.1;
const MAX_HOLD_SESSIONS = 3;

export function expectancy(e: Edge) {
  return e.settled ? e.totalR / e.settled : 0;
}
export function winRate(e: Edge) {
  return e.settled ? e.wins / e.settled : 0;
}

function rng(seed: number): [number, number] {
  let a = seed | 0;
  a = (a + 0x6d2b79f5) | 0;
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  const u = ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  return [a >>> 0, u];
}

function take(s: OperatorState): number {
  const [seed, u] = rng(s.seed);
  s.seed = seed;
  return u;
}

function log(s: OperatorState, kind: string, text: string) {
  s.seq += 1;
  s.logs.unshift({ id: s.seq, tick: s.tick, kind, text });
  if (s.logs.length > 28) s.logs.pop();
}

function blankLedger(): Record<MarketId, MarketPnl> {
  return { SP500: { earned: 0, lost: 0 }, NDX100: { earned: 0, lost: 0 }, BTC: { earned: 0, lost: 0 }, ETH: { earned: 0, lost: 0 }, GOLD: { earned: 0, lost: 0 }, WTI: { earned: 0, lost: 0 } };
}

function market(id: MarketId): Market {
  const base: Record<MarketId, [string, number, number, Regime]> = {
    SP500: ["S&P 500", 5784, 0.0042, "RANGE"],
    NDX100: ["NASDAQ", 20140, 0.0055, "RANGE"],
    BTC: ["Bitcoin", 67840, 0.012, "VOL"],
    ETH: ["Ether", 3520, 0.015, "VOL"],
    GOLD: ["Gold", 2684, 0.006, "TREND"],
    WTI: ["WTI", 71.4, 0.009, "TREND"],
  };
  const [label, px, atrPct, regime] = base[id];
  return {
    id,
    label,
    px,
    anchor: px,
    chg: 0,
    atrPct,
    adx: regime === "TREND" ? 28 : regime === "VOL" ? 24 : 16,
    regime,
    feed: "LIVE",
    session: id === "BTC" || id === "ETH" || id === "GOLD" || id === "WTI",
    london: id === "GOLD",
    spark: Array.from({ length: 24 }, () => px),
  };
}

function seedEdges(): Edge[] {
  return [
    {
      id: "mr15_spx",
      market: "SP500",
      strategy: "mr15",
      name: "MR15 snap-back",
      tf: "15m",
      thesis: "Fade a stretch from the session mean when the index is ranging.",
      settled: 14,
      wins: 8,
      totalR: 1.6,
      earned: false,
      gen: 6,
      gene: "stretch 2.2×ATR · ADX≤22 · 13:30–20:00Z",
      bias: 0.54,
      targetR: 1.1,
      maxBars: 6,
      enabled: true,
      why: "",
      allocation: 0,
    },
    {
      id: "mr15_ndx",
      market: "NDX100",
      strategy: "mr15",
      name: "MR15 snap-back",
      tf: "15m",
      thesis: "Same snap-back, never held with S&P — one correlated bloc.",
      settled: 11,
      wins: 5,
      totalR: -0.4,
      earned: false,
      gen: 5,
      gene: "stretch 2.4×ATR · ADX≤20 · cash hours",
      bias: 0.51,
      targetR: 1.1,
      maxBars: 6,
      enabled: true,
      why: "",
      allocation: 0,
    },
    {
      id: "btc_mom",
      market: "BTC",
      strategy: "mom_breakout",
      name: "Momentum breakout",
      tf: "1h",
      thesis: "Donchian break only if volume and displacement say the move is real.",
      settled: 64,
      wins: 24,
      totalR: -11.2,
      earned: false,
      gen: 18,
      gene: "24h channel · vol≥1.8× · disp 1.2×ATR",
      bias: 0.39,
      targetR: 1.8,
      maxBars: 10,
      enabled: true,
      why: "",
      allocation: 0,
    },
    {
      id: "gold_trend",
      market: "GOLD",
      strategy: "trend4h",
      name: "Trend4h wave",
      tf: "4h",
      thesis: "Commodities trend in cleaner waves. Pullback to the fast EMA.",
      settled: 41,
      wins: 17,
      totalR: 10.4,
      earned: true,
      gen: 11,
      gene: "EMA 21/55 · ADX≥22 · stop 1.6×ATR · 2.0R",
      bias: 0.45,
      targetR: 2,
      maxBars: 12,
      enabled: true,
      why: "",
      allocation: 0,
    },
    {
      id: "wti_trend",
      market: "WTI",
      strategy: "trend4h",
      name: "Trend4h wave",
      tf: "4h",
      thesis: "Oil rides the same slow wave. No entry noise.",
      settled: 23,
      wins: 9,
      totalR: 2.1,
      earned: false,
      gen: 9,
      gene: "EMA 21/55 · ADX≥24 · stop 1.8×ATR",
      bias: 0.42,
      targetR: 1.8,
      maxBars: 12,
      enabled: true,
      why: "",
      allocation: 0,
    },
    {
      id: "gold_school",
      market: "GOLD",
      strategy: "school_run",
      name: "School run",
      tf: "1h",
      thesis: "Overnight range, first London break, one trade, then done.",
      settled: 36,
      wins: 21,
      totalR: 12.2,
      earned: true,
      gen: 8,
      gene: "range 00–07Z · window 2h · ≤3×ATR",
      bias: 0.58,
      targetR: 1.6,
      maxBars: 4,
      enabled: true,
      why: "",
      allocation: 0,
    },
    {
      id: "btc_sibe",
      market: "BTC",
      strategy: "sibe",
      name: "SIBE",
      tf: "1h",
      thesis: "Sweep, invert, break of structure, then entry. Stop under the raid.",
      settled: 52,
      wins: 25,
      totalR: -1.8,
      earned: false,
      gen: 22,
      gene: "16h raid · disp 1.4×ATR · stop at sweep",
      bias: 0.49,
      targetR: 1.5,
      maxBars: 8,
      enabled: true,
      why: "",
      allocation: 0,
    },
    {
      id: "btc_vwap",
      market: "BTC",
      strategy: "vwap",
      name: "VWAP",
      tf: "1h",
      thesis: "Session VWAP fade only when the regime is a range, not a trend.",
      settled: 33,
      wins: 18,
      totalR: -0.9,
      earned: false,
      gen: 14,
      gene: "fade 2.0σ · ADX≤20 · mode gene live",
      bias: 0.5,
      targetR: 1.2,
      maxBars: 6,
      enabled: true,
      why: "",
      allocation: 0,
    },
    {
      id: "eth_mom",
      market: "ETH",
      strategy: "mom_breakout",
      name: "Momentum breakout",
      tf: "1h",
      thesis: "Same displacement rule as Bitcoin. Ether only. No smaller coins.",
      settled: 8,
      wins: 3,
      totalR: 0.4,
      earned: false,
      gen: 2,
      gene: "24h channel · vol≥1.8× · disp 1.2×ATR",
      bias: 0.48,
      targetR: 1.8,
      maxBars: 10,
      enabled: true,
      why: "",
      allocation: 0,
    },
  ];
}

function refreshGates(s: OperatorState) {
  let weight = 0;
  for (const e of s.edges) {
    const exp = expectancy(e);
    const wr = winRate(e);
    if (!e.earned && e.settled >= EARN_MIN_BETS && exp >= EARN_MIN_EXP && wr >= EARN_MIN_WIN) {
      e.earned = true;
      log(s, "EARNED", `${e.name} on ${e.market} earned real stakes — ${e.settled} bets, ${exp >= 0 ? "+" : ""}${exp.toFixed(2)}R, ${(wr * 100).toFixed(0)}% wins.`);
    } else if (e.earned && e.settled >= EARN_MIN_BETS && exp < 0) {
      e.earned = false;
      log(s, "DEMOTE", `${e.name} on ${e.market} lost real stakes — expectancy fell to ${exp.toFixed(2)}R. Back to paper.`);
    }
    e.allocation = e.earned ? Math.max(exp, 0.05) : 0;
    weight += e.allocation;
  }
  if (weight > 0) {
    for (const e of s.edges) e.allocation = e.earned ? e.allocation / weight : 0;
  }
}

function regimeAllows(e: Edge, m: Market): string | null {
  if (m.feed !== "LIVE") return "feed not live — standing down";
  if (e.strategy === "mr15") {
    if (!m.session) return "cash session closed";
    if (m.regime !== "RANGE" || m.adx > 22) return "index is trending — fades off";
    return null;
  }
  if (e.strategy === "mom_breakout") {
    if (m.regime === "RANGE" || m.adx < 18) return "no displacement regime";
    return null;
  }
  if (e.strategy === "trend4h") {
    if (m.regime !== "TREND" || m.adx < 22) return "wave not clean enough";
    return null;
  }
  if (e.strategy === "school_run") {
    if (!m.london) return "outside the London window";
    return null;
  }
  if (e.strategy === "vwap") {
    if (m.regime !== "RANGE") return "VWAP fade refused in trend";
    return null;
  }
  if (e.strategy === "sibe") {
    if (m.regime === "VOL" && m.adx > 32) return "volatility too wild for structure";
    return null;
  }
  return null;
}

function pushPx(m: Market, u: number, drift: number) {
  const shock = (u - 0.5) * m.atrPct * m.px * 0.55;
  const pull = (m.anchor - m.px) * (m.regime === "RANGE" ? 0.08 : 0.01);
  const trend = m.regime === "TREND" ? drift * m.atrPct * m.px * 0.15 : 0;
  const prev = m.px;
  m.px = Math.max(m.px * 0.2, m.px + shock + pull + trend);
  m.chg = (m.px - prev) / prev;
  m.spark.push(m.px);
  if (m.spark.length > 28) m.spark.shift();
  m.adx = Math.min(48, Math.max(8, m.adx + (u - 0.48) * 3));
}

const CORE_BOOK = 2_300_000;
const CRYPTO_BOOK = 3_000_000;

function idleFunding(): Funding {
  return { asset: "USDC", network: "Arbitrum", amountUsd: 0, confirmations: 0, need: 12, status: "idle", ref: "" };
}

export function createInitial(): OperatorState {
  const s: OperatorState = {
    seed: 0x0c10e,
    tick: 0,
    seq: 0,
    bankroll: CORE_BOOK,
    peak: CORE_BOOK,
    halted: false,
    cool: 0,
    realLock: 0,
    cryptoBook: CRYPTO_BOOK,
    cryptoPeak: CRYPTO_BOOK,
    cryptoEquity: [CRYPTO_BOOK],
    cryptoHalted: false,
    cryptoCool: 0,
    cryptoLock: 0,
    funding: idleFunding(),
    markets: (["SP500", "NDX100", "BTC", "ETH", "GOLD", "WTI"] as MarketId[]).map(market),
    edges: seedEdges(),
    positions: [],
    closed: [],
    ledger: blankLedger(),
    logs: [],
    equity: [CORE_BOOK],
    returns: { SP500: [], NDX100: [], BTC: [], ETH: [], GOLD: [], WTI: [] },
    clockMin: 13 * 60 + 30,
    human: "None. Charter is enforcing itself.",
    healed: 0,
    skipped: 0,
    fills: 0,
  };
  refreshGates(s);
  log(s, "SYSTEM", "Operator online. Firm is $5.3 million. Crypto desk is walled off. No human in the loop.");
  for (let i = 0; i < 36; i++) step(s, i < 28);
  anchorBook(s);
  log(s, "FUND", "Moved $3,000,000 onto the crypto desk, settled as USDC. Core book left at $2,300,000. Further funds arrive only by crypto transfer.");
  return s;
}

function pinPath(equity: number[], book: number) {
  const last = equity.at(-1) || book;
  const hi = Math.max(...equity, last);
  const pathScale = hi > 0 ? book / hi : 1;
  const next = equity.map((v) => Math.round(v * pathScale * 100) / 100);
  next[next.length - 1] = book;
  return { next, scale: last > 0 ? book / last : 1, peak: book };
}

/** Warmup writes the path. The desks are then set back to $2.3 million and $3 million. */
function anchorBook(s: OperatorState) {
  const core = pinPath(s.equity, CORE_BOOK);
  const crypto = pinPath(s.cryptoEquity, CRYPTO_BOOK);
  s.equity = core.next;
  s.bankroll = CORE_BOOK;
  s.peak = core.peak;
  s.cryptoEquity = crypto.next;
  s.cryptoBook = CRYPTO_BOOK;
  s.cryptoPeak = crypto.peak;
  for (const p of s.positions) {
    const scale = isCrypto(p.market) ? crypto.scale : core.scale;
    p.riskUsd = Math.round(p.riskUsd * scale * 100) / 100;
  }
  for (const c of s.closed) {
    const scale = isCrypto(c.market) ? crypto.scale : core.scale;
    c.pnl = Math.round(c.pnl * scale * 100) / 100;
  }
  for (const id of Object.keys(s.ledger) as MarketId[]) {
    const scale = isCrypto(id) ? crypto.scale : core.scale;
    const row = s.ledger[id];
    row.earned = Math.round(row.earned * scale * 100) / 100;
    row.lost = Math.round(row.lost * scale * 100) / 100;
  }
}

function step(s: OperatorState, quiet: boolean) {
  s.tick += 1;
  s.clockMin += 15;
  advanceFunding(s, quiet);

  for (const m of s.markets) {
    if (m.feed === "HEALING") {
      m.feed = "LIVE";
      s.healed += 1;
      if (!quiet) log(s, "HEAL", `${m.label} feed restored from the fallback source. Entries allowed again.`);
    } else if (m.feed === "STALE") {
      m.feed = "HEALING";
    } else if (take(s) < 0.035) {
      m.feed = "STALE";
      if (!quiet) log(s, "HEAL", `${m.label} primary feed lagged. Operator switched sources — no new risk until it is live.`);
    }

    const hour = Math.floor((s.clockMin % (24 * 60)) / 60);
    if (m.id === "SP500" || m.id === "NDX100") m.session = hour >= 13 && hour < 20;
    if (m.id === "GOLD") m.london = hour >= 7 && hour < 10;
    if (m.id !== "BTC" && m.id !== "GOLD" && m.id !== "WTI") {
      /* session set above */
    }

    if (take(s) < 0.04) {
      const order: Regime[] = ["RANGE", "TREND", "VOL"];
      const next = order[Math.floor(take(s) * 3)] ?? "RANGE";
      if (next !== m.regime) {
        m.regime = next;
        if (!quiet) log(s, "REGIME", `${m.label} regime is now ${next}. Families that do not fit are switched off.`);
      }
    }

    const drift = m.id === "GOLD" || m.id === "WTI" ? 0.35 : isCrypto(m.id) ? 0.05 : -0.05;
    const prev = m.px;
    pushPx(m, take(s), drift);
    const ret = (m.px - prev) / prev;
    s.returns[m.id].push(ret);
    if (s.returns[m.id].length > 48) s.returns[m.id].shift();
  }

  if (s.halted) {
    flatten(s, "guard", quiet, (id) => !isCrypto(id));
    if (s.cool > 0) s.cool -= 1;
    if (s.realLock > 0) s.realLock -= 1;
    if (s.cool === 0 && s.halted && (s.peak - s.bankroll) / s.peak < DD_GUARD) {
      s.halted = false;
      if (!quiet) log(s, "SYSTEM", "Core halt lifted. Learning resumes on the core book. Its real sleeve stays locked until that window ends.");
    }
  } else if (s.realLock > 0) s.realLock -= 1;

  if (s.cryptoHalted) {
    flatten(s, "guard", quiet, isCrypto);
    if (s.cryptoCool > 0) s.cryptoCool -= 1;
    if (s.cryptoLock > 0) s.cryptoLock -= 1;
    if (s.cryptoCool === 0 && s.cryptoHalted && (s.cryptoPeak - s.cryptoBook) / s.cryptoPeak < DD_GUARD) {
      s.cryptoHalted = false;
      if (!quiet) log(s, "SYSTEM", "Crypto halt lifted. The crypto desk resumes. Its real sleeve stays locked until that window ends.");
    }
  } else if (s.cryptoLock > 0) s.cryptoLock -= 1;

  for (const p of s.positions) {
    const m = s.markets.find((x) => x.id === p.market)!;
    const riskPx = Math.abs(p.entry - p.stop) || m.px * 0.004;
    const signed = p.side === "LONG" ? m.px - p.entry : p.entry - m.px;
    p.unrealR = signed / riskPx;
    p.bars += 1;
  }

  const still: Position[] = [];
  for (const p of s.positions) {
    let reason: string | null = null;
    let r = p.unrealR;
    if (p.unrealR <= -1) {
      reason = "stop";
      r = -1;
    } else if (p.unrealR >= p.targetR) {
      reason = "target";
      r = p.targetR;
    } else if (p.bars >= p.maxBars || p.bars >= MAX_HOLD_SESSIONS * 4) {
      reason = "time";
      r = Math.max(-1, Math.min(p.targetR, p.unrealR));
    }
    if (!reason) {
      still.push(p);
      continue;
    }
    settle(s, p, r, reason, quiet);
  }
  s.positions = still;

  refreshGates(s);

  for (const e of s.edges) {
    const m = s.markets.find((x) => x.id === e.market)!;
    const block = regimeAllows(e, m);
    e.enabled = !block;
    e.why = block ?? "filters clear — operator may enter";
    if (block) {
      s.skipped += 1;
      continue;
    }
    if (s.positions.some((p) => p.edgeId === e.id)) continue;
    const crypto = isCrypto(e.market);
    if (crypto ? s.cryptoHalted : s.halted) {
      e.why = crypto ? "crypto desk is halted" : "core book is halted";
      continue;
    }
    const onDesk = s.positions.filter((p) => isCrypto(p.market) === crypto);
    if (onDesk.length >= (crypto ? 2 : 3)) {
      e.why = "that desk is full — operator waits";
      continue;
    }
    const bloc = s.positions.some((p) => p.market === "SP500" || p.market === "NDX100");
    if ((e.market === "SP500" || e.market === "NDX100") && bloc) {
      e.why = "pair lock — S&P and NASDAQ are one bloc";
      continue;
    }
    if (crypto && s.positions.some((p) => p.market === e.market)) {
      e.why = "one position per coin";
      continue;
    }
    if (take(s) > 0.22) continue;

    const lock = crypto ? s.cryptoLock : s.realLock;
    const earnedOk = e.earned && lock === 0;
    const sleeve: Sleeve = earnedOk ? "REAL" : "LEARN";
    const desk = crypto ? s.cryptoBook : s.bankroll;
    const base = sleeve === "REAL" ? desk * REAL_CAP * Math.max(e.allocation, 0.15) : desk;
    const riskPct = sleeve === "REAL" ? REAL_RISK : e.gen % 5 === 0 ? CHALLENGER_RISK : LEARN_RISK;
    const riskUsd = Math.max(0.5, base * riskPct);
    const stopDist = Math.min(2.5, 1.15) * m.atrPct * m.px;
    const side: Side = take(s) > 0.5 ? "LONG" : "SHORT";
    const entry = m.px;
    const stop = side === "LONG" ? entry - stopDist : entry + stopDist;
    const target = side === "LONG" ? entry + stopDist * e.targetR : entry - stopDist * e.targetR;
    s.seq += 1;
    s.positions.push({
      id: `p${s.seq}`,
      edgeId: e.id,
      market: e.market,
      name: e.name,
      side,
      entry,
      stop,
      target,
      riskUsd,
      sleeve,
      bars: 0,
      maxBars: e.maxBars,
      unrealR: 0,
      targetR: e.targetR,
    });
    s.fills += 1;
    if (!quiet) {
      log(
        s,
        "FILL",
        `${sleeve} ${side} ${e.market} via ${e.name} on the ${crypto ? "crypto" : "core"} desk. Risk $${riskUsd.toFixed(2)} · stop inside 2.5×ATR · target ${e.targetR.toFixed(1)}R rests with the order.`,
      );
    }
  }

  if (s.tick % 7 === 0) mutate(s, quiet);

  s.peak = Math.max(s.peak, s.bankroll);
  s.cryptoPeak = Math.max(s.cryptoPeak, s.cryptoBook);
  const coreDd = s.peak > 0 ? (s.peak - s.bankroll) / s.peak : 0;
  const cryptoDd = s.cryptoPeak > 0 ? (s.cryptoPeak - s.cryptoBook) / s.cryptoPeak : 0;
  if (!s.halted && coreDd >= DD_GUARD) {
    s.halted = true;
    s.cool = 8;
    s.realLock = 16;
    flatten(s, "10% guard", quiet, (id) => !isCrypto(id));
    if (!quiet) log(s, "HALT", "Core book is 10% off its peak. Core positions flattened. The crypto desk is left alone.");
  }
  if (!s.cryptoHalted && cryptoDd >= DD_GUARD) {
    s.cryptoHalted = true;
    s.cryptoCool = 8;
    s.cryptoLock = 16;
    flatten(s, "10% guard", quiet, isCrypto);
    if (!quiet) log(s, "HALT", "Crypto desk is 10% off its peak. Crypto positions flattened. The core book is left alone.");
  }
  s.human = s.halted
    ? `Core halt is on. Cooling ${s.cool} bars. Crypto desk is ${s.cryptoHalted ? "also halted" : "still working"}.`
    : s.cryptoHalted
      ? `Crypto halt is on. Cooling ${s.cryptoCool} bars. Core book is still working.`
      : "None. Both desks enforce the charter on their own.";

  s.equity.push(Math.round(s.bankroll * 100) / 100);
  if (s.equity.length > 72) s.equity.shift();
  s.cryptoEquity.push(Math.round(s.cryptoBook * 100) / 100);
  if (s.cryptoEquity.length > 72) s.cryptoEquity.shift();
}

function advanceFunding(s: OperatorState, quiet: boolean) {
  const f = s.funding;
  if (!f || (f.status !== "watching" && f.status !== "confirming")) return;
  f.status = "confirming";
  f.confirmations += 1;
  if (f.confirmations < f.need) {
    if (!quiet && f.confirmations === 1) log(s, "FUND", `${f.asset} transfer ${f.ref} seen on ${f.network}. ${f.confirmations} of ${f.need} confirmations.`);
    return;
  }
  s.cryptoBook = Math.round((s.cryptoBook + f.amountUsd) * 100) / 100;
  s.cryptoPeak += f.amountUsd;
  f.status = "credited";
  if (!quiet) log(s, "FUND", `${f.asset} transfer credited ${moneyPlain(f.amountUsd)} to the crypto desk. Core book was not touched.`);
}

function moneyPlain(n: number) {
  return `$${n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function startFunding(prev: OperatorState, asset: FundAsset, amountUsd: number): OperatorState {
  const s: OperatorState = structuredClone(prev);
  if (!s.funding || s.funding.status === "watching" || s.funding.status === "confirming") return s;
  const amount = Math.round(amountUsd * 100) / 100;
  if (!Number.isFinite(amount) || amount < 1000) return s;
  const network = asset === "BTC" ? "Bitcoin" : "Arbitrum";
  const need = asset === "BTC" ? 3 : 12;
  s.seq += 1;
  s.funding = {
    asset,
    network,
    amountUsd: amount,
    confirmations: 0,
    need,
    status: "watching",
    ref: `CF-${s.tick}-${s.seq}`,
  };
  log(s, "FUND", `Watching ${moneyPlain(amount)} via ${asset} on ${network}. It credits the crypto desk after ${need} confirmations. This preview takes no real coins.`);
  return s;
}

function settle(s: OperatorState, p: Position, r: number, reason: string, quiet: boolean) {
  const pnl = p.riskUsd * r;
  if (isCrypto(p.market)) s.cryptoBook = Math.round((s.cryptoBook + pnl) * 100) / 100;
  else s.bankroll = Math.round((s.bankroll + pnl) * 100) / 100;
  const row = s.ledger[p.market];
  if (pnl >= 0) row.earned = Math.round((row.earned + pnl) * 100) / 100;
  else row.lost = Math.round((row.lost + Math.abs(pnl)) * 100) / 100;
  const e = s.edges.find((x) => x.id === p.edgeId);
  if (e) {
    e.settled += 1;
    e.totalR += r;
    if (r > 0) e.wins += 1;
    const u = take(s);
    if (r > 0 && u < 0.15) e.bias = Math.min(0.66, e.bias + 0.004);
    if (r < 0 && u < 0.15) e.bias = Math.max(0.32, e.bias - 0.004);
  }
  s.closed.unshift({
    id: p.id,
    name: p.name,
    market: p.market,
    side: p.side,
    sleeve: p.sleeve,
    r,
    pnl,
    reason,
    tick: s.tick,
  });
  if (s.closed.length > 12) s.closed.pop();
  if (!quiet) {
    const sign = r >= 0 ? "+" : "";
    log(s, reason === "stop" ? "STOP" : reason === "target" ? "TARGET" : "TIME", `${p.sleeve} ${p.side} ${p.market} ${p.name} closed on ${reason} · ${sign}${r.toFixed(2)}R · ${pnl >= 0 ? "+" : ""}$${pnl.toFixed(2)}.`);
  }
}

function flatten(s: OperatorState, why: string, quiet: boolean, keep: (id: MarketId) => boolean) {
  const stay: Position[] = [];
  for (const p of s.positions) {
    if (keep(p.market)) settle(s, p, Math.max(-1, p.unrealR), why, quiet);
    else stay.push(p);
  }
  s.positions = stay;
}

function mutate(s: OperatorState, quiet: boolean) {
  const e = s.edges[Math.floor(take(s) * s.edges.length)];
  if (!e) return;
  e.gen += 1;
  const tweaks = [
    "stop tightened inside the 2.5×ATR cap",
    "time stop pulled inside 3 sessions",
    "regime filter made stricter",
    "target left alone — evidence did not support widening",
    "volume confirmation raised",
  ];
  const twist = tweaks[Math.floor(take(s) * tweaks.length)] ?? tweaks[0];
  e.gene = e.gene.split(" · ").slice(0, 2).join(" · ") + ` · g${e.gen}`;
  if (!quiet) log(s, "MUTATION", `${e.name} gen ${e.gen} written — ${twist}. It does not touch the bankroll until it earns the book.`);
}

export function tickOperator(prev: OperatorState): OperatorState {
  if (prev.cryptoBook == null || prev.funding == null || prev.ledger == null) return createInitial();
  const s: OperatorState = structuredClone(prev);
  step(s, false);
  return s;
}

/** Advance the tape. Callers batch large gaps; one call stays bounded. */
export function rollOperator(prev: OperatorState, ticks: number): OperatorState {
  if (prev.cryptoBook == null || prev.funding == null || prev.ledger == null) return createInitial();
  const n = Math.max(0, Math.min(2000, Math.floor(ticks)));
  if (n === 0) return prev;
  const s: OperatorState = structuredClone(prev);
  for (let i = 0; i < n; i++) step(s, true);
  return s;
}

export function ddFromPeak(s: OperatorState) {
  return s.peak > 0 ? (s.peak - s.bankroll) / s.peak : 0;
}

export function cryptoDd(s: OperatorState) {
  return s.cryptoPeak > 0 ? (s.cryptoPeak - s.cryptoBook) / s.cryptoPeak : 0;
}

export function corr(a: number[], b: number[]) {
  const n = Math.min(a.length, b.length);
  if (n < 8) return 0;
  const as = a.slice(-n);
  const bs = b.slice(-n);
  const ma = as.reduce((x, y) => x + y, 0) / n;
  const mb = bs.reduce((x, y) => x + y, 0) / n;
  let num = 0;
  let da = 0;
  let db = 0;
  for (let i = 0; i < n; i++) {
    const xa = as[i] - ma;
    const xb = bs[i] - mb;
    num += xa * xb;
    da += xa * xa;
    db += xb * xb;
  }
  if (da === 0 || db === 0) return 0;
  return num / Math.sqrt(da * db);
}

export function clockLabel(min: number) {
  const day = Math.floor(min / (24 * 60));
  const m = ((min % (24 * 60)) + 24 * 60) % (24 * 60);
  const hh = String(Math.floor(m / 60)).padStart(2, "0");
  const mm = String(m % 60).padStart(2, "0");
  return `D+${day} ${hh}:${mm} UTC`;
}
