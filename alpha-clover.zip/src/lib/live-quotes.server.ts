import type { MarketId, OperatorState } from "@/lib/operator";
import type { Bar, Tf } from "@/lib/quotes";

const CHART: Record<string, string> = {
  AAPL: "AAPL",
  MSFT: "MSFT",
  NVDA: "NVDA",
  AMZN: "AMZN",
  GOOGL: "GOOGL",
  META: "META",
  TSLA: "TSLA",
  JPM: "JPM",
  XOM: "XOM",
  LLY: "LLY",
  BTC: "BTC-USD",
  ETH: "ETH-USD",
  SOL: "SOL-USD",
  XRP: "XRP-USD",
  EURUSD: "EURUSD=X",
  GBPUSD: "GBPUSD=X",
  USDJPY: "USDJPY=X",
  USDCHF: "USDCHF=X",
  AUDUSD: "AUDUSD=X",
  USDCAD: "USDCAD=X",
};

const DESK: Record<MarketId, string> = {
  SP500: "^GSPC",
  NDX100: "^NDX",
  BTC: "BTC-USD",
  ETH: "ETH-USD",
  GOLD: "GC=F",
  WTI: "CL=F",
};

const TF: Record<Tf, { interval: string; range: string }> = {
  "1m": { interval: "1m", range: "1d" },
  "5m": { interval: "5m", range: "5d" },
  "15m": { interval: "15m", range: "5d" },
  "1H": { interval: "60m", range: "1mo" },
  "4H": { interval: "60m", range: "3mo" },
  "1D": { interval: "1d", range: "6mo" },
};

type YahooChart = {
  chart?: {
    result?: Array<{
      meta?: { regularMarketPrice?: number; previousClose?: number; chartPreviousClose?: number };
      timestamp?: number[];
      indicators?: {
        quote?: Array<{
          open?: Array<number | null>;
          high?: Array<number | null>;
          low?: Array<number | null>;
          close?: Array<number | null>;
          volume?: Array<number | null>;
        }>;
      };
    }>;
  };
};

type Mark = { px: number; chg: number; spark: number[] };

const TTL = 15_000;
const barCache = new Map<string, { at: number; bars: Bar[] }>();
let deskCache: { at: number; marks: Partial<Record<MarketId, Mark>> } | null = null;

function barsFrom(row: {
  timestamp?: number[];
  indicators?: {
    quote?: Array<{
      open?: Array<number | null>;
      high?: Array<number | null>;
      low?: Array<number | null>;
      close?: Array<number | null>;
      volume?: Array<number | null>;
    }>;
  };
} | undefined): Bar[] {
  const ts = row?.timestamp ?? [];
  const q = row?.indicators?.quote?.[0];
  const bars: Bar[] = [];
  for (let i = 0; i < ts.length; i++) {
    const o = q?.open?.[i];
    const h = q?.high?.[i];
    const l = q?.low?.[i];
    const c = q?.close?.[i];
    if (o == null || h == null || l == null || c == null) continue;
    if (![o, h, l, c].every((n) => Number.isFinite(n) && n > 0)) continue;
    bars.push({ t: ts[i] * 1000, o, h, l, c, v: Math.round(q?.volume?.[i] ?? 0) });
  }
  return bars;
}

function bucket4h(bars: Bar[]): Bar[] {
  const groups = new Map<number, Bar>();
  for (const bar of bars) {
    const key = Math.floor(bar.t / 14_400_000) * 14_400_000;
    const group = groups.get(key);
    if (!group) {
      groups.set(key, { ...bar, t: key });
      continue;
    }
    group.h = Math.max(group.h, bar.h);
    group.l = Math.min(group.l, bar.l);
    group.c = bar.c;
    group.v += bar.v;
  }
  return [...groups.values()].sort((a, b) => a.t - b.t);
}

async function yahoo(symbol: string, interval: string, range: string) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=${interval}&range=${range}`;
  const res = await fetch(url, { headers: { accept: "application/json", "user-agent": "Mozilla/5.0" } });
  if (!res.ok) throw new Error("The live price did not load.");
  const body = (await res.json()) as YahooChart;
  const row = body.chart?.result?.[0];
  if (!row?.meta?.regularMarketPrice) throw new Error("The live price did not load.");
  return row;
}

function pinLast(bars: Bar[], px: number) {
  const last = bars[bars.length - 1];
  if (!last || !Number.isFinite(px) || px <= 0) return bars;
  last.c = px;
  last.h = Math.max(last.h, px);
  last.l = Math.min(last.l, px);
  return bars;
}

export function chartSymbol(symbol: string) {
  return CHART[symbol.toUpperCase()] ? symbol.toUpperCase() : null;
}

export async function liveBars(symbol: string, tf: Tf): Promise<Bar[]> {
  const yahooSymbol = CHART[symbol];
  const spec = TF[tf];
  if (!yahooSymbol || !spec) throw new Error("No live feed for that market.");
  const key = `${symbol}|${tf}`;
  const hit = barCache.get(key);
  if (hit && Date.now() - hit.at < TTL) return hit.bars;
  const row = await yahoo(yahooSymbol, spec.interval, spec.range);
  let bars = barsFrom(row);
  if (tf === "4H") bars = bucket4h(bars);
  bars = pinLast(bars.slice(-96), row.meta?.regularMarketPrice ?? 0);
  if (!bars.length) throw new Error("The live price did not load.");
  barCache.set(key, { at: Date.now(), bars });
  return bars;
}

async function loadDesk() {
  const ids = Object.keys(DESK) as MarketId[];
  const settled = await Promise.all(
    ids.map(async (id) => {
      try {
        const row = await yahoo(DESK[id], "15m", "5d");
        const px = row.meta?.regularMarketPrice ?? 0;
        const prev = row.meta?.previousClose || row.meta?.chartPreviousClose || px;
        const closes = barsFrom(row).map((b) => b.c).slice(-24);
        if (!Number.isFinite(px) || px <= 0) return null;
        const spark = closes.length ? closes : [px];
        spark[spark.length - 1] = px;
        return [id, { px, chg: prev ? (px - prev) / prev : 0, spark }] as const;
      } catch {
        return null;
      }
    }),
  );
  const marks: Partial<Record<MarketId, Mark>> = { ...(deskCache?.marks ?? {}) };
  let fresh = 0;
  for (const row of settled) {
    if (!row) continue;
    marks[row[0]] = row[1];
    fresh += 1;
  }
  if (fresh) deskCache = { at: Date.now(), marks };
  return marks;
}

/** Replaces the displayed mark on a cloned book. The simulated tape is left alone. */
export async function applyLiveMarks(book: OperatorState) {
  const stale = !deskCache || Date.now() - deskCache.at >= TTL;
  const marks = stale ? await loadDesk() : deskCache!.marks;
  for (const market of book.markets) {
    const mark = marks[market.id];
    if (!mark) continue;
    market.quote = mark.px;
    market.quoteSpark = mark.spark;
  }
}
