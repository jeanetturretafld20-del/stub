import { createServerFn } from "@tanstack/react-start";

export const sendAccountLetter = createServerFn({ method: "POST" })
  .validator((input: { email: string; callbackURL: string }) => {
    const email = input.email.trim().toLowerCase();
    const callbackURL = input.callbackURL.trim();
    if (!email.includes("@") || !/^https?:\/\//i.test(callbackURL)) {
      throw new Error("The letter could not be sent.");
    }
    return { email, callbackURL };
  })
  .handler(async ({ data }) => {
    const { getRequest } = await import("@tanstack/react-start/server");
    const { deliverVerification, withMailboxToken } = await import("@/lib/verify-mail.server");
    const { issueVerificationUrl } = await import("@/lib/send-letter.server");
    const request = getRequest();
    const token = request?.headers.get("x-connector-access-token")?.trim() || null;
    const { url, name } = await issueVerificationUrl(data.email, data.callbackURL);
    try {
      await withMailboxToken(token, () => deliverVerification({ to: data.email, name, url }));
    } catch (err) {
      const message = err instanceof Error ? err.message : "";
      if (/already confirmed|Open the account/i.test(message)) throw err;
      console.error("[verify-mail]", message.replace(/https?:\/\/\S+/g, "[link]").replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "[mailbox]"));
      throw new Error("The letter could not be sent.");
    }
    return { ok: true as const };
  });
