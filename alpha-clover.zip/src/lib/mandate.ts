/** Broker fee on profit. Due before a profit withdrawal can complete. */
export const BROKER_FEE = 0.2;
export const CONTRACT_MONTHS = 12;
/** Principal on the mandate. It is not profit, and it stays until the contract ends. */
export const MANDATE_CAPITAL = 5_300_000;

export function feeOn(profit: number) {
  const fee = Math.round(profit * BROKER_FEE * 100) / 100;
  const net = Math.round((profit - fee) * 100) / 100;
  return { fee, net };
}

export function contractEnd(openedAt: Date) {
  const ends = new Date(openedAt);
  ends.setMonth(ends.getMonth() + CONTRACT_MONTHS);
  return ends;
}
