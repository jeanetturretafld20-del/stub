import { getSql } from "@/lib/db";

export type Letter = {
  id: string;
  subject: string;
  body: string;
  createdAt: string;
};

const ADMIN_LINE = "You hold the desk.";

function letter(name: string, admin: boolean) {
  const who = name.trim() || "Client";
  if (admin) {
    return {
      subject: "Your account is confirmed",
      body: `${who}, this letter confirms the account. You opened the link. You hold the desk. The book is already working, whether or not you are watching it.`,
    };
  }
  return {
    subject: "Your account is confirmed",
    body: `${who}, this letter confirms the account. You opened the link. Capital you send is traded on the book. The tape keeps running after you leave this page.`,
  };
}

async function file(userId: string, name: string, admin: boolean) {
  const sql = await getSql();
  const note = letter(name, admin);
  if (admin) {
    await sql.query(
      `insert into post (id, user_id, subject, body)
       select $1, $2, $3, $4
       where not exists (select 1 from post where user_id = $2 and body like $5)`,
      [crypto.randomUUID(), userId, note.subject, note.body, `%${ADMIN_LINE}%`],
    );
    return;
  }
  await sql.query(
    `insert into post (id, user_id, subject, body)
     select $1, $2, $3, $4
     where not exists (select 1 from post where user_id = $2)`,
    [crypto.randomUUID(), userId, note.subject, note.body],
  );
}

export async function listPost(userId: string, name: string, admin: boolean): Promise<Letter[]> {
  const sql = await getSql();
  const note = letter(name, admin);
  await sql.query(
    `update post set subject = $1, body = $2 where user_id = $3 and body ilike '%no email to wait on%'`,
    [note.subject, note.body, userId],
  );
  if (admin) await file(userId, name, true);
  else await file(userId, name, false);
  const rows = await sql.query<{ id: string; subject: string; body: string; created_at: string | Date }>(
    "select id, subject, body, created_at from post where user_id = $1 order by created_at asc",
    [userId],
  );
  return rows.map((row) => ({
    id: row.id,
    subject: row.subject,
    body: row.body,
    createdAt: new Date(row.created_at).toISOString(),
  }));
}
