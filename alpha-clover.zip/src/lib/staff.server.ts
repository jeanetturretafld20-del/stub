import { getSql } from "@/lib/db";
import { FIRM_EMAIL } from "@/lib/firm";

const RETIRED_ADMINS = ["ada.portfolio@example.com", "aorendorff37@gmail.com", "alphaclover07@gmail.com"];

export async function roleFor(userId: string, email: string) {
  const sql = await getSql();
  const normalized = email.trim().toLowerCase();
  for (const retired of RETIRED_ADMINS) {
    await sql.query(
      `delete from staff where user_id in (select id from "user" where lower(email) = $1)`,
      [retired],
    );
  }
  if (normalized === FIRM_EMAIL) {
    await sql.query(
      `insert into staff (user_id, role) values ($1, 'admin')
       on conflict (user_id) do update set role = 'admin'`,
      [userId],
    );
  }
  const rows = await sql.query<{ role: string }>(`select role from staff where user_id = $1`, [userId]);
  return rows[0]?.role === "admin" ? "admin" : "client";
}
