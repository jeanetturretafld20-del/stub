import { getSql } from "@/lib/db";
import { createInitial, rollOperator, tickOperator, type OperatorState } from "@/lib/operator";

const TICK_MS = 1400;
/** One roll stays inside rollOperator's bound. The clock then continues. */
const BATCH = 2000;
/** Cold start may replay a long silence before the first answer. The timer finishes the rest. */
const BOOT_BUDGET_MS = 8000;

type Slot = {
  state: OperatorState;
  at: number;
  behind: number;
  writes: number;
  timer?: ReturnType<typeof setTimeout>;
  ready?: Promise<void>;
  chain: Promise<void>;
};

const g = globalThis as typeof globalThis & { __cloverTape?: Slot };

function slot(): Slot {
  g.__cloverTape ??= {
    state: createInitial(),
    at: Date.now(),
    behind: 0,
    writes: 0,
    chain: Promise.resolve(),
  };
  return g.__cloverTape;
}

function valid(state: OperatorState | null | undefined): state is OperatorState {
  return Boolean(state && state.ledger && state.funding && state.bankroll != null && state.cryptoBook != null);
}

/** Missed ticks since the last stamp. No cap: a quiet night is still on the tape. */
function missedSince(at: number, now = Date.now()) {
  if (!Number.isFinite(at)) return 0;
  return Math.max(0, Math.floor((now - at) / TICK_MS));
}

async function persist(current: Slot) {
  const snapshot = JSON.stringify(current.state);
  const at = current.at;
  const sql = await getSql();
  await sql.query(
    `insert into tape (id, state, at) values (1, $1::jsonb, to_timestamp($2 / 1000.0))
     on conflict (id) do update set state = excluded.state, at = excluded.at`,
    [snapshot, at],
  );
}

function arm(ms: number) {
  const current = slot();
  if (current.timer) clearTimeout(current.timer);
  current.timer = setTimeout(() => {
    current.chain = current.chain
      .then(() => stepOnce())
      .catch((err) => {
        console.error("[tape]", err);
        arm(TICK_MS);
      });
  }, ms);
  current.timer.unref?.();
}

function advance(current: Slot, ticks: number) {
  const n = Math.max(0, Math.floor(ticks));
  if (n === 0) return;
  current.state = n === 1 ? tickOperator(current.state) : rollOperator(current.state, n);
  current.at += n * TICK_MS;
  current.behind = Math.max(0, current.behind - n);
}

async function stepOnce() {
  const current = slot();
  let pause = TICK_MS;
  try {
    const gap = missedSince(current.at);
    if (gap > 1) {
      current.behind = gap;
      advance(current, Math.min(current.behind, BATCH));
      if (current.behind === 0) current.at = Date.now();
      pause = current.behind > 0 ? 8 : TICK_MS;
    } else {
      advance(current, 1);
      current.at = Date.now();
      current.behind = 0;
      pause = TICK_MS;
    }
    current.writes += 1;
    const due = current.behind === 0 ? current.writes >= 4 : true;
    if (due) {
      current.writes = 0;
      await persist(current);
    }
  } catch (err) {
    console.error("[tape]", err);
    pause = TICK_MS;
  }
  arm(pause);
}

async function replay(current: Slot, budgetMs: number) {
  const deadline = Date.now() + budgetMs;
  const gap = missedSince(current.at);
  if (gap > current.behind) current.behind = gap;
  while (current.behind > 0 && Date.now() < deadline) {
    advance(current, Math.min(current.behind, BATCH));
  }
  if (current.behind === 0) current.at = Date.now();
  await persist(current);
}

async function boot() {
  const current = slot();
  const sql = await getSql();
  const rows = await sql.query<{ state: OperatorState | string; at: string | Date }>(
    "select state, at from tape where id = 1",
  );
  const row = rows[0];
  let saved: OperatorState | null = null;
  if (row?.state) {
    saved = typeof row.state === "string" ? (JSON.parse(row.state) as OperatorState) : row.state;
  }
  if (valid(saved) && row) {
    const at = new Date(row.at).getTime();
    current.state = saved;
    current.at = Number.isFinite(at) ? at : Date.now();
    current.behind = missedSince(current.at);
  } else {
    current.state = createInitial();
    current.at = Date.now();
    current.behind = 0;
    await persist(current);
  }
  if (current.behind > 0) await replay(current, BOOT_BUDGET_MS);
  arm(current.behind > 0 ? 0 : TICK_MS);
}

/** Starts the clock. Repeated calls are free. The timer keeps going after the caller returns. */
export function ensureTape(): Promise<void> {
  const current = slot();
  current.ready ??= boot().catch((err) => {
    current.ready = undefined;
    throw err;
  });
  return current.ready.then(() => {
    if (!current.timer) arm(current.behind > 0 ? 0 : TICK_MS);
  });
}

export async function readTape(): Promise<{ book: OperatorState; behind: number }> {
  await ensureTape();
  const current = slot();
  return { book: structuredClone(current.state), behind: current.behind };
}

export async function tapePulse(): Promise<{ ok: true; behind: number; at: number; tick: number }> {
  await ensureTape();
  const current = slot();
  return { ok: true, behind: current.behind, at: current.at, tick: current.state.tick };
}
