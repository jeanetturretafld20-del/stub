import { createFileRoute } from "@tanstack/react-router";
import { OperatorApp } from "@/components/operator-app";

export const Route = createFileRoute("/desk")({
  component: OperatorApp,
});
