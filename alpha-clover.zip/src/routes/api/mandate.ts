import { createFileRoute } from "@tanstack/react-router";
import { capitalRefusal, confirmFeePaid, getMandate, requestProfitWithdrawal } from "@/lib/mandate.server";

async function sessionUser(request: Request) {
  const { readAccount } = await import("@/lib/auth/account.server");
  const user = await readAccount(request.headers);
  if (!user) return null;
  const opened = user.createdAt ? new Date(user.createdAt) : new Date();
  return { id: user.id, opened };
}

export const Route = createFileRoute("/api/mandate")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const user = await sessionUser(request);
        if (!user) return Response.json({ error: "Sign in first." }, { status: 401 });
        return Response.json(await getMandate(user.id, user.opened));
      },
      POST: async ({ request }) => {
        const user = await sessionUser(request);
        if (!user) return Response.json({ error: "Sign in first." }, { status: 401 });
        const body = (await request.json().catch(() => null)) as { action?: string; amount?: number; realized?: number } | null;
        if (body?.action === "capital") {
          const mandate = await getMandate(user.id, user.opened);
          if (mandate.locked) return Response.json({ error: capitalRefusal(mandate.contractEnds), mandate }, { status: 403 });
          return Response.json({ error: "The contract has ended. Capital is released by the desk, not from this button.", mandate }, { status: 403 });
        }
        if (body?.action === "withdraw") {
          const result = await requestProfitWithdrawal(user.id, user.opened, Number(body.amount), Number(body.realized));
          if ("error" in result && result.error) return Response.json(result, { status: 400 });
          return Response.json(result);
        }
        if (body?.action === "pay") {
          const result = await confirmFeePaid(user.id, user.opened);
          if ("error" in result && result.error) return Response.json(result, { status: 400 });
          return Response.json(result);
        }
        return Response.json({ error: "Unknown request." }, { status: 400 });
      },
    },
  },
});
