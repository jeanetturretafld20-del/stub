import { createFileRoute } from "@tanstack/react-router";
import type { Tf } from "@/lib/quotes";

const TFS = new Set(["1m", "5m", "15m", "1H", "4H", "1D"]);

export const Route = createFileRoute("/api/market")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const symbol = (url.searchParams.get("symbol") || "BTC").toUpperCase();
        const tf = url.searchParams.get("tf") || "15m";
        if (!TFS.has(tf)) return Response.json({ error: "No live feed for that market." }, { status: 404 });
        try {
          const { chartSymbol, liveBars } = await import("@/lib/live-quotes.server");
          if (!chartSymbol(symbol)) return Response.json({ error: "No live feed for that market." }, { status: 404 });
          const bars = await liveBars(symbol, tf as Tf);
          return Response.json({ symbol, tf, bars });
        } catch {
          return Response.json({ error: "The live price did not load." }, { status: 502 });
        }
      },
    },
  },
});
