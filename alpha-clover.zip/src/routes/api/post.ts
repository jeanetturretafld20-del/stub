import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/post")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const { readAccount } = await import("@/lib/auth/account.server");
        const { roleFor } = await import("@/lib/staff.server");
        const { listPost } = await import("@/lib/post.server");
        const user = await readAccount(request.headers);
        if (!user) return Response.json({ error: "Sign in first." }, { status: 401 });
        const role = await roleFor(user.id, user.email);
        const letters = await listPost(user.id, user.name, role === "admin");
        return Response.json({ letters });
      },
    },
  },
});
