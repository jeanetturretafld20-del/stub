import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/book")({
  server: {
    handlers: {
      GET: async () => {
        const { readTape } = await import("@/lib/tape.server");
        const { applyLiveMarks } = await import("@/lib/live-quotes.server");
        const tape = await readTape();
        await applyLiveMarks(tape.book);
        return Response.json(tape);
      },
    },
  },
});
