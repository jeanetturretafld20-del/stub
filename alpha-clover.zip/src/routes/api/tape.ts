import { createFileRoute } from "@tanstack/react-router";

/** Keeps the firm tape moving when no browser is open. Cron and the process boot both hit this. */
export const Route = createFileRoute("/api/tape")({
  server: {
    handlers: {
      GET: async () => {
        try {
          const { tapePulse } = await import("@/lib/tape.server");
          const pulse = await tapePulse();
          return Response.json(pulse);
        } catch (err) {
          const message = err instanceof Error ? err.message : String(err);
          console.error("[tape]", err);
          return Response.json({ ok: false, error: message }, { status: 500 });
        }
      },
    },
  },
});
