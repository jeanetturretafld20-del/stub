import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/me")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const { readAccount } = await import("@/lib/auth/account.server");
        const { roleFor } = await import("@/lib/staff.server");
        const { listPost } = await import("@/lib/post.server");
        const { getSql } = await import("@/lib/db");
        const user = await readAccount(request.headers);
        if (!user) return Response.json({ error: "Sign in first." }, { status: 401 });
        const sql = await getSql();
        const verified = await sql.query<{ verified: boolean | null }>(
          `select "emailVerified" as verified from "user" where id = $1`,
          [user.id],
        );
        const emailVerified = verified[0]?.verified === true;
        const credential = await sql.query<{ ok: number }>(
          `select 1 as ok from account where "userId" = $1 and "providerId" = 'credential' limit 1`,
          [user.id],
        );
        const needsVerification = credential.length > 0 && !emailVerified;
        const role = await roleFor(user.id, user.email);
        if (!needsVerification) await listPost(user.id, user.name, role === "admin");
        const { hasKyc } = await import("@/lib/kyc.server");
        const filed = role === "admin" ? true : await hasKyc(user.id);
        return Response.json({
          role,
          name: role === "admin" ? "Alpha Clover" : user.name,
          needsVerification,
          needsKyc: !needsVerification && !filed,
        });
      },
    },
  },
});
