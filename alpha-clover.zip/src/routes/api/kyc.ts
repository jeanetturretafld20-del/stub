import { createFileRoute } from "@tanstack/react-router";
import { checkKyc, fileKyc, hasKyc, type KycInput } from "@/lib/kyc.server";

async function userId(request: Request) {
  const { readAccount } = await import("@/lib/auth/account.server");
  const user = await readAccount(request.headers);
  return user?.id ?? null;
}

export const Route = createFileRoute("/api/kyc")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const id = await userId(request);
        if (!id) return Response.json({ error: "Sign in first." }, { status: 401 });
        return Response.json({ filed: await hasKyc(id) });
      },
      POST: async ({ request }) => {
        const id = await userId(request);
        if (!id) return Response.json({ error: "Sign in first." }, { status: 401 });
        const body = (await request.json().catch(() => null)) as Partial<KycInput> | null;
        if (!body || typeof body.pep !== "boolean") {
          return Response.json({ error: "Say whether you are a politically exposed person." }, { status: 400 });
        }
        const input: KycInput = {
          legalName: body.legalName ?? "",
          dateOfBirth: body.dateOfBirth ?? "",
          citizenship: body.citizenship ?? "",
          residence: body.residence ?? "",
          address: body.address ?? "",
          city: body.city ?? "",
          region: body.region ?? "",
          postal: body.postal ?? "",
          phone: body.phone ?? "",
          employment: body.employment ?? "",
          source: body.source ?? "",
          taxId: body.taxId ?? "",
          taxKind: body.taxKind ?? "",
          idType: body.idType ?? "",
          idNumber: body.idNumber ?? "",
          pep: body.pep,
        };
        const problem = checkKyc(input);
        if (problem) return Response.json({ error: problem }, { status: 400 });
        await fileKyc(id, input);
        return Response.json({ filed: true });
      },
    },
  },
});
