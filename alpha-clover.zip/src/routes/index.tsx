import { createFileRoute } from "@tanstack/react-router";
import { ClientApp } from "@/components/client-app";

export const Route = createFileRoute("/")({ component: ClientApp });
