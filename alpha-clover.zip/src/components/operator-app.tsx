import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Activity, Clover, Lock, Radio, Shield, ShieldAlert } from "lucide-react";
import { PageLoading } from "@/components/page-loading";
import { TerminalChart } from "@/components/terminal-chart";
import { subscribeBook } from "@/lib/book-store";
import { FUNDING_WALLET } from "@/lib/funding-wallet";
import { formatDesk } from "@/lib/quotes";
import {
  clockLabel,
  corr,
  cryptoDd,
  ddFromPeak,
  expectancy,
  isCrypto,
  winRate,
  type Edge,
  type Market,
  type OperatorState,
} from "@/lib/operator";

const VERSION = "5.8";
type Desk = "ops" | "chart" | "crypto" | "evolution" | "tape" | "confidence" | "research" | "execution" | "digest";
const DESKS: { id: Desk; label: string }[] = [
  { id: "ops", label: "Operator" },
  { id: "chart", label: "Chart" },
  { id: "crypto", label: "Crypto" },
  { id: "evolution", label: "Evolution" },
  { id: "tape", label: "Tape" },
  { id: "confidence", label: "Confidence" },
  { id: "research", label: "Research" },
  { id: "execution", label: "Execution" },
  { id: "digest", label: "Digest" },
];

function money(n: number) {
  return `${n < 0 ? "-" : ""}$${Math.abs(n).toLocaleString("en-US", {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	})}`;
}

function rTxt(n: number) {
  return `${n >= 0 ? "+" : ""}${n.toFixed(2)}R`;
}

function Spark({ values, up }: { values: number[]; up?: boolean }) {
  const w = 120;
  const h = 36;
  if (values.length < 2) return null;
  const min = Math.min(...values);
  const span = Math.max(...values) - min || 1;
  const d = values.map((v, i) => {
		const x = i / (values.length - 1) * w;
		const y = h - (v - min) / span * 32 - 2;
		return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
	}).join(" ");
  return (<svg className="h-9 w-full" viewBox={`0 0 ${w} ${h}`} aria-hidden={true}><path d={d} className={`${up === void 0 ? "stroke-primary" : up ? "stroke-primary" : "stroke-danger"} fill-none`} strokeWidth={"1.6"} /></svg>);
}

function Panel({ title, aside, children }: { title: string; aside?: ReactNode; children: ReactNode }) {
  return (<section className="rounded-lg border border-line bg-surface">
  <header className="flex items-center justify-between gap-3 border-b border-line px-3 py-2">
    <h2 className="text-xs font-medium tracking-wide text-muted uppercase">{title}</h2>
    {aside ? (<span className="font-data text-xs text-muted">{aside}</span>) : null}
  </header>
  <div className="p-3">{children}</div>
</section>);
}

export function OperatorApp() {
  const [state, setState] = useState<OperatorState | null>(null);
  const [behind, setBehind] = useState(0);
  const [desk, setDesk] = useState<Desk>("ops");
  useEffect(() => subscribeBook((view) => {
    setState(view.book);
    setBehind(view.behind);
  }), []);
  if (!state) return <PageLoading />;
  const firm = state.bankroll + state.cryptoBook;
  return (<div className="min-h-screen bg-bg text-fg">
  <header className="border-b border-line">
    <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3">
      <div className="flex items-center gap-2">
        <Clover className="size-5 text-primary" />
        <div>
          <div className="text-sm font-semibold tracking-wide">Alpha Clover</div>
          <div className="font-data text-xs text-muted">
            v
            {VERSION}
          </div>
        </div>
      </div>
      <a className="text-xs text-muted" href="/">Clients</a>
      <div className="font-data text-xs text-muted">{clockLabel(state.clockMin)}</div>
      <div className="ml-auto flex flex-wrap items-center gap-2">
        <StatusChip live={!state.halted} label={state.halted ? "Halted" : state.realLock > 0 ? "Learning only" : "Autonomous"} />
      </div>
    </div>
    <div className="mx-auto grid max-w-6xl grid-cols-2 gap-px border-t border-line bg-line sm:grid-cols-4">
      <Metric k={"Firm"} v={money(firm)} sub={"core plus crypto"} />
      <Metric k={"Core book"} v={money(state.bankroll)} sub={`${(ddFromPeak(state) * 100).toFixed(1)}% from peak`} warn={ddFromPeak(state) > .06} />
      <Metric k={"Crypto desk"} v={money(state.cryptoBook)} sub={"client deposits"} warn={cryptoDd(state) > .06} />
      <Metric k={"You"} v={"Not needed"} sub={state.human} />
    </div>
  </header>
  <nav className="border-b border-line">
    <div className="mx-auto flex max-w-6xl gap-1 overflow-x-auto px-3 py-2">
      {DESKS.map((d) => (<button type="button" onClick={() => setDesk(d.id)} className={`shrink-0 rounded-md px-3 py-2 text-sm ${desk === d.id ? "bg-primary-dim text-primary" : "text-muted"}`}>{d.label}</button>))}
    </div>
  </nav>
  <main className="mx-auto max-w-6xl px-4 py-4">
    <p className="mb-4 text-sm text-muted">
      Clients fund at the address on the Crypto desk. Firm is 
      {money(firm)}
      . 
      {money(state.cryptoBook)}
       is the crypto book. The desk does not read the wallet. The tape runs whether or not anyone is watching.
      {behind > 20 ? " It is writing the time that passed with nobody on the desk." : ""}
    </p>
    {desk === "ops" ? (<Ops state={state} />) : null}
    {desk === "chart" ? (<TerminalChart />) : null}
    {desk === "crypto" ? (<CryptoDesk state={state} />) : null}
    {desk === "evolution" ? (<Evolution state={state} />) : null}
    {desk === "tape" ? (<Tape state={state} />) : null}
    {desk === "confidence" ? (<Confidence state={state} />) : null}
    {desk === "research" ? (<Research state={state} />) : null}
    {desk === "execution" ? (<Execution state={state} />) : null}
    {desk === "digest" ? (<Digest state={state} />) : null}
  </main>
</div>);
}

function StatusChip({ live, label }: { live: boolean; label: string }) {
  return (<span className={`inline-flex items-center gap-2 rounded-md border px-3 py-2 text-xs ${live ? "border-primary/40 bg-primary-dim text-primary" : "border-danger/40 bg-elevated text-danger"}`}>
  <span className={`size-1.5 rounded-full ${live ? "bg-primary" : "bg-danger"}`} />
  {label}
</span>);
}

function Metric({ k, v, sub, warn }: { k: string; v: string; sub: string; warn?: boolean }) {
  return (<div className="bg-bg px-4 py-3">
  <div className="text-xs text-muted">{k}</div>
  <div className={`font-data text-base tracking-tight sm:text-lg ${warn ? "text-amber" : "text-fg"}`}>{v}</div>
  <div className="truncate text-xs text-muted">{sub}</div>
</div>);
}

function Ops({ state }: { state: OperatorState }) {
  const breakers = [
		{
			name: "Drawdown",
			on: ddFromPeak(state) < .1,
			detail: `${(ddFromPeak(state) * 100).toFixed(1)}% of 10%`
		},
		{
			name: "Pair lock",
			on: true,
			detail: "S&P and NASDAQ cannot both be on"
		},
		{
			name: "Stop cap",
			on: true,
			detail: "Never wider than 2.5×ATR"
		},
		{
			name: "Real sleeve",
			on: state.realLock === 0 && !state.halted,
			detail: state.realLock ? `locked ${state.realLock} bars` : "only earned classes"
		},
		{
			name: "Feeds",
			on: state.markets.every((m) => m.feed === "LIVE"),
			detail: state.markets.filter((m) => m.feed !== "LIVE").map((m) => m.label).join(", ") || "all live"
		}
	];
  return (<div className="grid gap-3 lg:grid-cols-5">
  <div className="lg:col-span-5">
    <Panel title={"What each market made"} aside={"closed trades only"}>
      <ul className="divide-y divide-line">
        {state.markets.map((m) => {
const row = state.ledger[m.id];
const net = row.earned - row.lost;
return (<li className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1 py-2 text-sm">
  <span>{m.label}</span>
  <span className={`font-data ${row.earned > 0 ? "text-primary" : "text-muted"}`}>
    +
    {money(row.earned)}
  </span>
  <span className={`font-data ${row.lost > 0 ? "text-danger" : "text-muted"}`}>
    −
    {money(row.lost)}
  </span>
  <span className={`font-data ${net > 0 ? "text-primary" : net < 0 ? "text-danger" : "text-muted"}`}>
    {net >= 0 ? "+" : "−"}
    {money(Math.abs(net))}
  </span>
</li>);
})}
      </ul>
      <p className="mt-3 text-xs text-muted">Green is what that market earned. Red is what it lost. Open trades are not in either number.</p>
    </Panel>
  </div>
  <div className="grid gap-3 lg:col-span-3">
    <Panel title={"What the operator is doing"} aside={`${state.healed} self-heals · ${state.fills} entries`}>
      <ul className="space-y-2">
        {state.logs.slice(0, 10).map((l) => (<li className="grid grid-cols-[4.5rem_1fr] gap-3 text-sm">
  <span className={`font-data text-xs ${tone(l.kind)}`}>{l.kind}</span>
  <span className="text-fg">{l.text}</span>
</li>))}
      </ul>
    </Panel>
    <Panel title={"Families"} aside={"core book only — coins live on the crypto desk"}>
      <ul className="divide-y divide-line">
        {state.edges.filter((e) => !isCrypto(e.market)).map((e) => (<li className="flex items-start justify-between gap-3 py-2 first:pt-0 last:pb-0">
  <div>
    <div className="text-sm">
      {e.name}
       
      <span className="text-muted">{e.market}</span>
    </div>
    <div className="text-xs text-muted">{e.why}</div>
  </div>
  <span className={`font-data shrink-0 text-xs ${e.enabled ? "text-primary" : "text-muted"}`}>{e.enabled ? "ON" : "OFF"}</span>
</li>))}
      </ul>
    </Panel>
  </div>
  <div className="grid gap-3 lg:col-span-2">
    <Panel title={"What changed in 5.8"} aside={"on top of 5.7"}>
      <ul className="space-y-3">
        {[["Heartbeat", "Feeds heal themselves. A stale source blocks new risk until it is live again."], ["Earn and demote", "Real stakes appear at 20 bets, +0.15R, 40% wins, and leave when expectancy goes negative."], ["Regime switch", "Each market only runs the family that fits. Flat is a decision."], ["Halt", "Ten percent off the peak flattens the book, cools, then resumes learning alone."]].map(([name, detail]) => (<li>
  <div className="text-sm">{name}</div>
  <div className="text-xs text-muted">{detail}</div>
</li>))}
      </ul>
    </Panel>
    <Panel title={"Circuit breakers"} aside={state.halted ? "halt engaged" : "clear"}>
      <ul className="space-y-3">
        {breakers.map((b) => (<li className="flex items-start gap-3">
  {b.on ? (<Shield className="mt-0.5 size-4 text-primary" />) : (<ShieldAlert className="mt-0.5 size-4 text-amber" />)}
  <div>
    <div className="text-sm">{b.name}</div>
    <div className="text-xs text-muted">{b.detail}</div>
  </div>
</li>))}
      </ul>
    </Panel>
    <Panel title={"Next human action"}>
      <div className="flex items-start gap-3">
        <Lock className="mt-0.5 size-4 text-primary" />
        <div>
          <div className="text-sm font-medium">None</div>
          <p className="mt-1 text-sm text-muted">{state.human}</p>
        </div>
      </div>
    </Panel>
    <Panel title={"Bankroll path"} aside={"learn + real, one account"}>
      <Spark values={state.equity} up={(state.equity.at(-1) ?? 0) >= (state.equity[0] ?? 0)} />
      <div className="mt-2 flex justify-between font-data text-xs text-muted">
        <span>
          Start 
          {money(state.equity[0] ?? 53e5)}
        </span>
        <span>
          Now 
          {money(state.bankroll)}
        </span>
      </div>
    </Panel>
  </div>
</div>);
}

function Confidence({ state }: { state: OperatorState }) {
  const rows = state.edges.map((e) => {
		const m = state.markets.find((x) => x.id === e.market);
		const exp = expectancy(e);
		const stretched = m != null && Math.abs(m.px - m.anchor) / m.anchor > m.atrPct * 2;
		const grade = !e.enabled ? "SKIP" : e.earned && exp >= .15 ? "A" : exp > 0 ? "B" : "C";
		return {
			e,
			grade,
			stretched,
			take: grade === "A" || grade === "B",
			exp
		};
	});
  return (<Panel title={"False-signal filter"} aside={"the operator obeys this, you do not"}>
  <ul className="divide-y divide-line">
    {rows.map(({ e, grade, stretched, take, exp }) => (<li className="flex items-start justify-between gap-3 py-2 first:pt-0 last:pb-0">
  <div>
    <div className="text-sm">
      {e.name}
       
      <span className="text-muted">{e.market}</span>
    </div>
    <div className="text-xs text-muted">
      {e.why}
      {stretched ? " · extended, not chased" : ""}
    </div>
  </div>
  <div className="text-right">
    <div className={`font-data text-sm ${take ? "text-primary" : "text-muted"}`}>{grade}</div>
    <div className="font-data text-xs text-muted">
      {take ? "eligible" : "ignored"}
       · 
      {rTxt(exp)}
    </div>
  </div>
</li>))}
  </ul>
</Panel>);
}

function CryptoDesk({ state }: { state: OperatorState }) {
  const markets = state.markets.filter((m) => isCrypto(m.id));
  const positions = state.positions.filter((p) => isCrypto(p.market));
  const edges = state.edges.filter((e) => isCrypto(e.market));
  const closed = state.closed.filter((c) => isCrypto(c.market));
  const risk = positions.reduce((a, p) => a + p.riskUsd, 0);
  return (<div className="grid gap-3 lg:grid-cols-5">
  <div className="grid gap-3 max-lg:order-2 lg:col-span-3">
    <Panel title={"Crypto book"} aside={state.cryptoHalted ? "halted" : "separate from the core book"}>
      <div className="mb-3 flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="font-data text-2xl tracking-tight">{money(state.cryptoBook)}</div>
          <div className="text-xs text-muted">
            Opened at $3,000,000. 
            {(cryptoDd(state) * 100).toFixed(1)}
            % from its own peak. Open risk 
            {money(risk)}
            .
          </div>
        </div>
        <div className="w-40"><Spark values={state.cryptoEquity} up={(state.cryptoEquity.at(-1) ?? 0) >= 3e6} /></div>
      </div>
      <p className="text-sm text-muted">Bitcoin and Ether only. A 10% drop on this desk flattens crypto and leaves the core book alone.</p>
    </Panel>
    <Panel title={"Coins"} aside={"majors"}>
      <ul className="divide-y divide-line">
        {markets.map((m) => (<li className="flex items-center justify-between gap-3 py-2 first:pt-0 last:pb-0">
  <div>
    <div className="text-sm">{m.label}</div>
    <div className="text-xs text-muted">
      {m.regime}
       · 
      {m.feed}
       · ATR 
      {(m.atrPct * 100).toFixed(1)}
      %
    </div>
  </div>
  <div className="w-24">
    <Spark values={m.quoteSpark ?? []} up={(m.quoteSpark?.at(-1) ?? 0) >= (m.quoteSpark?.[0] ?? 0)} />
    <div className="text-right font-data text-xs text-muted">{Number.isFinite(m.quote) ? formatDesk(m.quote as number) : "—"}</div>
  </div>
</li>))}
      </ul>
    </Panel>
    <Panel title={"Working on this desk"} aside={`${positions.length} open`}>
      {positions.length === 0 ? (<p className="text-sm text-muted">Flat. The operator is waiting for a regime that fits.</p>) : (<ul className="divide-y divide-line">
  {positions.map((p) => (<li className="flex items-start justify-between gap-3 py-2 first:pt-0 last:pb-0">
  <div>
    <div className="text-sm">
      {p.side}
       
      {p.market}
       · 
      {p.name}
    </div>
    <div className="font-data text-xs text-muted">
      risk 
      {money(p.riskUsd)}
       · 
      {p.sleeve}
       · 
      {rTxt(p.unrealR)}
    </div>
  </div>
  <span className="font-data text-xs text-muted">
    stop 
    {p.stop.toLocaleString("en-US", { maximumFractionDigits: 0 })}
  </span>
</li>))}
</ul>)}
    </Panel>
    <Panel title={"Families"} aside={"same earn gate, this book only"}>
      <ul className="divide-y divide-line">
        {edges.map((e) => (<li className="flex items-start justify-between gap-3 py-2 first:pt-0 last:pb-0">
  <div>
    <div className="text-sm">
      {e.name}
       
      <span className="text-muted">{e.market}</span>
    </div>
    <div className="text-xs text-muted">{e.why}</div>
  </div>
  <span className={`font-data shrink-0 text-xs ${e.enabled ? "text-primary" : "text-muted"}`}>{e.enabled ? "ON" : "OFF"}</span>
</li>))}
      </ul>
    </Panel>
  </div>
  <div className="grid gap-3 max-lg:order-1 lg:col-span-2">
    <Panel title={"Where clients send funds"} aside={"not watched"}>
      <img className="mb-3 h-40 w-40 bg-white p-1" src={"/funding-qr.jpg"} alt={"QR code for the firm funding address"} width={160} height={160} />
      <p className="break-all font-data text-sm">{FUNDING_WALLET}</p>
    </Panel>
    <Panel title={"Last crypto closes"} aside={`${closed.length} on the tape`}>
      {closed.length === 0 ? (<p className="text-sm text-muted">No crypto closes yet.</p>) : (<ul className="space-y-2">
  {closed.slice(0, 5).map((c) => (<li className="flex justify-between gap-3 text-sm">
  <span>
    {c.market}
     
    {c.side}
  </span>
  <span className={`font-data text-xs ${c.pnl >= 0 ? "text-primary" : "text-danger"}`}>
    {rTxt(c.r)}
     · 
    {money(c.pnl)}
  </span>
</li>))}
</ul>)}
    </Panel>
  </div>
</div>);
}

function tone(kind: string) {
  if (kind === "HALT" || kind === "STOP" || kind === "DEMOTE") return "text-danger";
  if (kind === "EARNED" || kind === "TARGET" || kind === "FILL" || kind === "FUND") return "text-primary";
  if (kind === "HEAL" || kind === "REGIME" || kind === "MUTATION") return "text-amber";
  return "text-muted";
}

function Evolution({ state }: { state: OperatorState }) {
  const settled = state.edges.reduce((a, e) => a + e.settled, 0);
  const totalR = state.edges.reduce((a, e) => a + e.totalR, 0);
  const wins = state.edges.reduce((a, e) => a + e.wins, 0);
  return (<div className="grid gap-3">
  <div className="grid gap-3 sm:grid-cols-3">
    <Panel title={"Settled expectancy"}>
      <div className={`font-data text-2xl ${totalR >= 0 ? "text-primary" : "text-danger"}`}>{rTxt(settled ? totalR / settled : 0)}</div>
      <div className="text-xs text-muted">
        {settled}
         bets · 
        {settled ? Math.round(wins / settled * 100) : 0}
        % wins
      </div>
    </Panel>
    <Panel title={"Real sleeve cap"}>
      <div className="font-data text-2xl">15%</div>
      <div className="text-xs text-muted">
        {money(state.bankroll * .15)}
         maximum. Shrunk to earned classes only.
      </div>
    </Panel>
    <Panel title={"Charter"}>
      <ul className="space-y-1 text-sm text-muted">
        <li>1% of bankroll per learn bet</li>
        <li>1% of the real sleeve when earned</li>
        <li>Gate: 20 bets, +0.15R, 40% wins</li>
      </ul>
    </Panel>
  </div>
  <Panel title={"Edge classes"} aside={"the machine promotes and demotes these"}>
    <div className="overflow-x-auto">
      <table className="w-full min-w-[40rem] text-left text-sm">
        <thead className="text-xs text-muted">
          <tr>
            <th className="pb-2 font-medium">Class</th>
            <th className="pb-2 font-medium">Status</th>
            <th className="pb-2 font-medium">Expectancy</th>
            <th className="pb-2 font-medium">Win</th>
            <th className="pb-2 font-medium">Settled</th>
            <th className="pb-2 font-medium">Real weight</th>
          </tr>
        </thead>
        <tbody>{state.edges.map((e) => (<EdgeRow e={e} />))}</tbody>
      </table>
    </div>
  </Panel>
</div>);
}

function EdgeRow({ e }: { e: Edge }) {
  const exp = expectancy(e);
  return (<tr className="border-t border-line">
  <td className="py-2">
    <div>{e.name}</div>
    <div className="text-xs text-muted">
      {e.market}
       · 
      {e.tf}
       · gen 
      {e.gen}
    </div>
    <div className="text-xs text-muted">{e.gene}</div>
  </td>
  <td className={`py-2 font-data text-xs ${e.earned ? "text-primary" : "text-muted"}`}>{e.earned ? "EARNED" : "PAPER"}</td>
  <td className={`py-2 font-data ${exp >= .15 ? "text-primary" : exp < 0 ? "text-danger" : "text-amber"}`}>{rTxt(exp)}</td>
  <td className="py-2 font-data">
    {(winRate(e) * 100).toFixed(0)}
    %
  </td>
  <td className="py-2 font-data">{e.settled}</td>
  <td className="py-2 font-data">{e.earned ? `${Math.round(e.allocation * 100)}%` : "—"}</td>
</tr>);
}

function Tape({ state }: { state: OperatorState }) {
  return (<div className="grid gap-3 lg:grid-cols-2">
  <Panel title={"Markets"} aside={"regime decides who is allowed to trade"}><ul className="space-y-3">{state.markets.map((m) => (<MarketRow m={m} />))}</ul></Panel>
  <div className="grid gap-3">
    <Panel title={"Open book"} aside={`${state.positions.length} positions`}>
      {state.positions.length === 0 ? (<p className="text-sm text-muted">Flat. The operator is waiting on regime, session, or the pair lock — that is a decision, not a stall.</p>) : (<ul className="space-y-3">
  {state.positions.map((p) => (<li className="flex items-start justify-between gap-3 text-sm">
  <div>
    <div>
      {p.side}
       
      {p.market}
       
      <span className="text-muted">{p.name}</span>
    </div>
    <div className="font-data text-xs text-muted">
      {p.sleeve}
       · risk 
      {money(p.riskUsd)}
       · bar 
      {p.bars}
      /
      {p.maxBars}
    </div>
  </div>
  <span className={`font-data ${p.unrealR >= 0 ? "text-primary" : "text-danger"}`}>{rTxt(p.unrealR)}</span>
</li>))}
</ul>)}
    </Panel>
    <Panel title={"Last closes"}>
      <ul className="space-y-2">
        {state.closed.slice(0, 6).map((c) => (<li className="flex justify-between gap-3 text-sm">
  <span>
    {c.side}
     
    {c.market}
     
    <span className="text-muted">{c.reason}</span>
  </span>
  <span className={`font-data ${c.r >= 0 ? "text-primary" : "text-danger"}`}>{rTxt(c.r)}</span>
</li>))}
      </ul>
    </Panel>
  </div>
</div>);
}

function MarketRow({ m }: { m: Market }) {
  const spark = m.quoteSpark ?? [];
  const up = (spark.at(-1) ?? 0) >= (spark[0] ?? 0);
  const live = Number.isFinite(m.quote);
  return (<li className="grid grid-cols-[1fr_5.5rem] items-center gap-3">
  <div>
    <div className="flex items-baseline justify-between gap-2">
      <span className="text-sm">{m.label}</span>
      <span className="font-data text-sm">{live ? formatDesk(m.quote as number) : "—"}</span>
    </div>
    <div className="mt-1 flex gap-2 text-xs text-muted">
      <span>{m.regime}</span>
      <span>
        ADX 
        {m.adx.toFixed(0)}
      </span>
      <span className={live ? "text-primary" : "text-amber"}>{live ? "LIVE" : "OFF"}</span>
    </div>
  </div>
  <Spark values={spark} up={up} />
</li>);
}

function Research({ state }: { state: OperatorState }) {
  const ids = state.markets.map((m) => m.id);
  const matrix = useMemo(() => {
		return ids.map((a) => ids.map((b) => a === b ? 1 : corr(state.returns[a], state.returns[b])));
	}, [state, ids]);
  const spxNdx = corr(state.returns.SP500, state.returns.NDX100);
  return (<div className="grid gap-3 lg:grid-cols-2">
  <Panel title={"Correlation from this tape"} aside={`${state.returns.SP500.length} bars`}>
    <p className="mb-3 text-sm text-muted">
      Computed from the operator’s own returns, not a borrowed matrix. S&P versus NASDAQ is 
      {(spxNdx * 100).toFixed(0)}
      % — the pair lock is there because of this, not as decoration.
    </p>
    <div className="overflow-x-auto">
      <table className="w-full text-left text-xs">
        <thead>
          <tr>
            <th className="p-1" />
            {ids.map((id) => (<th className="p-1 font-medium text-muted">{id === "NDX100" ? "NDX" : id === "SP500" ? "SPX" : id}</th>))}
          </tr>
        </thead>
        <tbody>
          {ids.map((id, i) => (<tr>
  <th className="p-1 text-left font-medium text-muted">{id === "NDX100" ? "NDX" : id === "SP500" ? "SPX" : id}</th>
  {matrix[i].map((v, j) => (<td className={`p-1 font-data ${v > .7 && i !== j ? "text-amber" : "text-fg"}`}>{i === j ? "—" : v.toFixed(2)}</td>))}
</tr>))}
        </tbody>
      </table>
    </div>
  </Panel>
  <Panel title={"What this desk will not invent"}>
    <ul className="space-y-3 text-sm">
      <li className="flex gap-3">
        <Radio className="mt-0.5 size-4 shrink-0 text-primary" />
        <span>No consensus estimates, no fake analyst targets, no implied-move numbers. Those feeds are not attached.</span>
      </li>
      <li className="flex gap-3">
        <Activity className="mt-0.5 size-4 shrink-0 text-primary" />
        <span>
          Valuation work stays on the server heartbeat in the full stack (SEC XBRL, live 10-year). This preview only shows what the operator can prove from its tape.
        </span>
      </li>
      <li className="flex gap-3">
        <Shield className="mt-0.5 size-4 shrink-0 text-primary" />
        <span>
          The worst open risk right now is 
          {money(state.positions.reduce((a, p) => a + p.riskUsd, 0))}
           if every stop fills. That is the number the guard watches.
        </span>
      </li>
    </ul>
  </Panel>
</div>);
}

function Execution({ state }: { state: OperatorState }) {
  return (<div className="grid gap-3 lg:grid-cols-2">
  <Panel title={"Venue posture"} aside={"paper"}>
    <dl className="grid grid-cols-2 gap-3 text-sm">
      <div>
        <dt className="text-xs text-muted">Mode</dt>
        <dd>{state.halted ? "Halted, flat" : "Autonomous paper"}</dd>
      </div>
      <div>
        <dt className="text-xs text-muted">Confirm prompts</dt>
        <dd>Off — rules already approved</dd>
      </div>
      <div>
        <dt className="text-xs text-muted">Stops</dt>
        <dd>Rest with every entry</dd>
      </div>
      <div>
        <dt className="text-xs text-muted">Crypto funding</dt>
        <dd>Client deposits. Wallet is not read.</dd>
      </div>
    </dl>
    <p className="mt-3 text-sm text-muted">
      Promotion to a live venue still needs a separate key and an explicit arm on your server. The operator will not cross that line by itself.
    </p>
  </Panel>
  <Panel title={"Working orders"}>
    {state.positions.length === 0 ? (<p className="text-sm text-muted">No working orders. Stops and targets are cancelled when the book is flat.</p>) : (<ul className="space-y-3">
  {state.positions.map((p) => (<li className="text-sm">
  <div className="flex justify-between">
    <span>
      {p.side}
       
      {p.market}
    </span>
    <span className="font-data text-xs text-muted">{p.sleeve}</span>
  </div>
  <div className="font-data text-xs text-muted">
    {rTxt(p.unrealR)}
     open · paper fill, not the live print
  </div>
</li>))}
</ul>)}
  </Panel>
</div>);
}

function Digest({ state }: { state: OperatorState }) {
  const best = [...state.closed].sort((a, b) => b.r - a.r)[0];
  const worst = [...state.closed].sort((a, b) => a.r - b.r)[0];
  return (<div className="grid gap-3">
  <Panel title={"Daily read"} aside={"written by the operator"}>
    <ol className="list-decimal space-y-3 pl-4 text-sm">
      <li>
        Firm 
        {money(state.bankroll + state.cryptoBook)}
        . Core book 
        {money(state.bankroll)}
        , crypto desk 
        {money(state.cryptoBook)}
        .
        {state.halted ? " The core guard has that book flat." : ""}
        {state.cryptoHalted ? " The crypto guard has that desk flat." : ""}
      </li>
      <li>
        {state.edges.filter((e) => e.earned).length}
         classes may use the real sleeve (
        {state.edges.filter((e) => e.earned).map((e) => `${e.name} ${e.market}`).join(", ") || "none"}
        ). Everyone else is learning on paper.
      </li>
      <li>
        {state.positions.length}
         positions working, 
        {money(state.positions.reduce((a, p) => a + p.riskUsd, 0))}
         of risk if every stop is hit.
        {best ? ` Best recent close ${best.market} ${rTxt(best.r)}.` : ""}
        {worst ? ` Worst ${worst.market} ${rTxt(worst.r)}.` : ""}
      </li>
    </ol>
  </Panel>
  <Panel title={"If it is not on this page"}>
    <p className="text-sm text-muted">It did not need you. Feeds heal themselves, weak classes lose real stakes, and a 10% drawdown flattens the book without a click.</p>
  </Panel>
</div>);
}
