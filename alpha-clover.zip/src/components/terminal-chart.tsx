import { useEffect, useMemo, useRef, useState, type PointerEvent } from "react";
import {
  INSTRUMENTS,
  TIMEFRAMES,
  formatPx,
  instrument,
  type AssetClass,
  type Bar,
  type Tf,
} from "@/lib/quotes";

const W = 900;
const H = 460;
const PAD_R = 74;
const TOP = 16;
const PLOT_H = 332;
const PLOT_W = W - PAD_R;

const CLASS_LABEL: Record<AssetClass, string> = {
  stock: "Stocks",
  crypto: "Crypto",
  fx: "FX",
};

const CHART_KEY = "alpha-clover.chart.v1";

function readChart() {
  try {
    const raw = localStorage.getItem(CHART_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as {
      symbol?: string;
      tf?: Tf;
      klass?: AssetClass;
      series?: Record<string, { at: number; bars: Bar[] }>;
    };
  } catch {
    return null;
  }
}

function remember(symbol: string, tf: Tf, klass: AssetClass) {
  try {
    const saved = readChart() ?? {};
    localStorage.setItem(CHART_KEY, JSON.stringify({ ...saved, symbol, tf, klass, series: undefined }));
  } catch {
    /* the chart still loads if storage is full */
  }
}

export function TerminalChart({ tone = "desk" }: { tone?: "desk" | "broker" }) {
  const [klass, setKlass] = useState<AssetClass>("stock");
  const [symbol, setSymbol] = useState("AAPL");
  const [tf, setTf] = useState<Tf>("15m");
  const [bars, setBars] = useState<Bar[]>([]);
  const [missed, setMissed] = useState(false);
  const [hover, setHover] = useState<number | null>(null);
  const [ready, setReady] = useState(false);
  const svgRef = useRef<SVGSVGElement>(null);
  const spec = instrument(symbol);
  const shown = useMemo(() => INSTRUMENTS.filter((i) => i.klass === klass), [klass]);

  useEffect(() => {
    const saved = readChart();
    const nextSymbol = saved?.symbol && INSTRUMENTS.some((i) => i.symbol === saved.symbol) ? saved.symbol : "AAPL";
    const nextTf = saved?.tf && TIMEFRAMES.includes(saved.tf) ? saved.tf : "15m";
    const nextKlass = saved?.klass ?? instrument(nextSymbol).klass;
    setSymbol(nextSymbol);
    setTf(nextTf);
    setKlass(nextKlass);
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    let stop = false;
    setBars([]);
    setHover(null);
    setMissed(false);
    remember(symbol, tf, klass);
    async function pull() {
      try {
        const res = await fetch(`/api/market?symbol=${encodeURIComponent(symbol)}&tf=${encodeURIComponent(tf)}`);
        if (stop) return;
        if (!res.ok) {
          setMissed(true);
          return;
        }
        const body = (await res.json()) as { bars?: Bar[] };
        if (body.bars?.length) {
          setBars(body.bars);
          setMissed(false);
        } else {
          setMissed(true);
        }
      } catch {
        if (!stop) setMissed(true);
      }
    }
    void pull();
    const id = window.setInterval(() => void pull(), 8000);
    return () => {
      stop = true;
      window.clearInterval(id);
    };
  }, [ready, symbol, tf, klass]);

  const last = bars[bars.length - 1];
  const first = bars[0];
  const chg = last && first ? (last.c - first.o) / first.o : 0;
  const up = chg >= 0;
  const active = hover != null ? bars[hover] : last;

  function pickClass(next: AssetClass) {
    setKlass(next);
    const firstIn = INSTRUMENTS.find((i) => i.klass === next);
    if (firstIn) setSymbol(firstIn.symbol);
  }

  function onMove(e: PointerEvent<SVGSVGElement>) {
    const svg = svgRef.current;
    if (!svg || bars.length < 2) return;
    const rect = svg.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * W;
    const slot = PLOT_W / bars.length;
    const i = Math.max(0, Math.min(bars.length - 1, Math.floor(x / slot)));
    setHover(i);
  }

  const broker = tone === "broker";
  const shell = broker
    ? "grid border border-et-line bg-et-card font-et text-et-ink lg:grid-cols-[200px_1fr]"
    : "grid border border-line lg:grid-cols-[200px_1fr]";
  const rule = broker ? "border-et-line" : "border-line";
  const quiet = broker ? "text-et-muted" : "text-muted";
  const on = broker ? "border-b-2 border-et-purple text-et-purple" : "bg-primary-dim text-primary";
  const rowOn = broker ? "border-l-2 border-et-purple bg-et-page" : "bg-elevated";
  const upTone = broker ? "text-et-up" : "text-primary";
  const downTone = broker ? "text-et-down" : "text-danger";

  return (
    <div className={shell}>
      <aside className={`border-b lg:border-r lg:border-b-0 ${rule}`}>
        <div className={`flex border-b ${rule}`}>
          {(["stock", "crypto", "fx"] as AssetClass[]).map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => pickClass(k)}
              className={`flex-1 px-2 py-2 text-xs ${klass === k ? on : quiet}`}
            >
              {CLASS_LABEL[k]}
            </button>
          ))}
        </div>
        <ul className="max-h-52 overflow-y-auto lg:max-h-[432px]">
          {shown.map((i) => (
            <li key={i.symbol}>
              <button
                type="button"
                onClick={() => setSymbol(i.symbol)}
                className={`flex w-full items-baseline justify-between gap-2 px-3 py-2 text-left ${symbol === i.symbol ? rowOn : ""}`}
              >
                <span>
                  <span className="font-data text-sm">{i.symbol}</span>
                  <span className={`ml-2 text-xs ${quiet}`}>{i.name}</span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      </aside>
      <div className="min-w-0">
        <div className={`flex flex-wrap items-center gap-x-4 gap-y-2 border-b px-3 py-2 ${rule}`}>
          <div>
            <div className="font-data text-sm">{spec.symbol}</div>
            <div className={`text-xs ${quiet}`}>{spec.name}</div>
          </div>
          <div className={`font-data text-lg ${up ? upTone : downTone}`}>{last ? formatPx(last.c, spec.digits) : "—"}</div>
          <div className={`font-data text-xs ${up ? upTone : downTone}`}>
            {up ? "+" : ""}
            {(chg * 100).toFixed(2)}%
          </div>
          <div className="ml-auto flex gap-1">
            {TIMEFRAMES.map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTf(t)}
                className={`rounded px-2 py-1 font-data text-xs ${tf === t ? on : quiet}`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>
        {active ? (
          <div className={`flex flex-wrap gap-x-3 gap-y-1 px-3 pt-2 font-data text-xs ${quiet}`}>
            <span>
              {new Date(active.t).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
            </span>
            <span>O {formatPx(active.o, spec.digits)}</span>
            <span>H {formatPx(active.h, spec.digits)}</span>
            <span>L {formatPx(active.l, spec.digits)}</span>
            <span className={active.c >= active.o ? upTone : downTone}>C {formatPx(active.c, spec.digits)}</span>
            <span>V {active.v.toLocaleString("en-US")}</span>
          </div>
        ) : null}
        <svg
          ref={svgRef}
          viewBox={`0 0 ${W} ${H}`}
          className="block h-auto w-full touch-none"
          onPointerMove={onMove}
          onPointerLeave={() => setHover(null)}
        >
          <ChartBars
            bars={bars}
            digits={spec.digits}
            hover={hover}
            upColor={broker ? "#067a32" : "#3cba86"}
            downColor={broker ? "#c41230" : "#e06a62"}
            grid={broker ? "#d5d5d5" : "#24302a"}
            axis={broker ? "#5c5c5c" : "#8d9a92"}
            cross={broker ? "#6b2c91" : "#e0b15a"}
          />
        </svg>
        <p className={`border-t px-3 py-2 text-xs ${rule} ${quiet}`}>
          {missed && !last ? "The live price did not load." : "Live price. It can sit a few seconds behind a phone."}
        </p>
      </div>
    </div>
  );
}

function ChartBars({
  bars,
  digits,
  hover,
  upColor,
  downColor,
  grid,
  axis,
  cross,
}: {
  bars: Bar[];
  digits: number;
  hover: number | null;
  upColor: string;
  downColor: string;
  grid: string;
  axis: string;
  cross: string;
}) {
  if (bars.length < 2) return null;
  const hi = Math.max(...bars.map((b) => b.h));
  const lo = Math.min(...bars.map((b) => b.l));
  const span = hi - lo || hi * 0.01 || 1;
  const slot = PLOT_W / bars.length;
  const bodyW = Math.max(2, slot * 0.62);
  const maxV = Math.max(...bars.map((b) => b.v), 1);
  const y = (p: number) => TOP + (1 - (p - lo) / span) * PLOT_H;
  const hoverBar = hover != null ? bars[hover] : null;
  const hoverX = hover != null ? hover * slot + slot / 2 : null;
  const last = bars[bars.length - 1];
  return (
    <>
      {Array.from({ length: 5 }, (_, i) => {
        const p = lo + (span * i) / 4;
        const yy = y(p);
        return (
          <g key={i}>
            <line x1={0} x2={PLOT_W} y1={yy} y2={yy} stroke={grid} strokeDasharray="3 4" />
            <text x={834} y={yy + 3} fill={axis} fontSize="11" fontFamily="IBM Plex Mono, ui-monospace, monospace">
              {formatPx(p, digits)}
            </text>
          </g>
        );
      })}
      <line x1={PLOT_W} x2={PLOT_W} y1={TOP} y2={434} stroke={grid} />
      {bars.map((b, i) => {
        const x = i * slot + slot / 2;
        const color = b.c >= b.o ? upColor : downColor;
        const top = y(Math.max(b.o, b.c));
        const bot = y(Math.min(b.o, b.c));
        const vh = (b.v / maxV) * 70;
        return (
          <g key={b.t}>
            <line x1={x} x2={x} y1={y(b.h)} y2={y(b.l)} stroke={color} strokeWidth="1.2" />
            <rect x={x - bodyW / 2} y={top} width={bodyW} height={Math.max(1, bot - top)} fill={color} />
            <rect x={x - bodyW / 2} y={434 - vh} width={bodyW} height={vh} fill={color} opacity="0.35" />
          </g>
        );
      })}
      <line
        x1={0}
        x2={PLOT_W}
        y1={y(last.c)}
        y2={y(last.c)}
        stroke={last.c >= bars[0].o ? upColor : downColor}
        strokeDasharray="4 3"
      />
      <text
        x={896}
        y={y(last.c) + 4}
        textAnchor="end"
        fill={last.c >= bars[0].o ? upColor : downColor}
        fontSize="11"
        fontFamily="IBM Plex Mono, ui-monospace, monospace"
      >
        {formatPx(last.c, digits)}
      </text>
      {hoverBar && hoverX != null ? (
        <>
          <line x1={hoverX} x2={hoverX} y1={TOP} y2={434} stroke={cross} strokeWidth="1" />
          <line x1={0} x2={PLOT_W} y1={y(hoverBar.c)} y2={y(hoverBar.c)} stroke={cross} strokeWidth="1" />
        </>
      ) : null}
    </>
  );
}
