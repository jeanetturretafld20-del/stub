import { useEffect, useRef, useState, type FormEvent } from "react";
import { Check } from "lucide-react";
import { authClient, authHeaders, captureSessionToken, signOut } from "@/lib/auth/client";
import { TerminalChart } from "@/components/terminal-chart";
import { FUNDING_WALLET } from "@/lib/funding-wallet";
import { FIRM_EMAIL } from "@/lib/firm";
import { formatDesk } from "@/lib/quotes";
import { sendAccountLetter } from "@/lib/send-letter";
import { BROKER_FEE, feeOn } from "@/lib/mandate";
import { subscribeBook } from "@/lib/book-store";
import type { OperatorState } from "@/lib/operator";

const MARKETS = [
  ["S&P 500", "15m", "Mean reversion, only while the index is ranging."],
  ["NASDAQ", "15m", "The same snap-back. Never held with the S&P."],
  ["Bitcoin", "1h", "Momentum breakout. One position. No smaller coins."],
  ["Ether", "1h", "The same breakout as Bitcoin."],
  ["Gold", "4h", "Trend, plus the London school-run window."],
  ["Oil", "4h", "Trend. A different book from gold."],
];

const ACCOUNTS_KEY = "alpha-clover.accounts";

type AccountKind = "brokerage" | "retirement" | "cash";

const ACCOUNT_TYPES: { id: AccountKind; title: string; badge?: string; body: string }[] = [
  {
    id: "brokerage",
    title: "Brokerage account",
    badge: "Required for crypto",
    body: "The trading book. Stocks, ETFs, crypto, foreign exchange, and the metals and energy the charter allows. The book places the trades.",
  },
  {
    id: "retirement",
    title: "Retirement account",
    body: "Held for retirement. Traditional, Roth, SEP, and rollover. The same book, kept until the date on the mandate.",
  },
  {
    id: "cash",
    title: "Savings, checking, and CD accounts",
    body: "Cash at the firm. A savings balance, a checking balance for transfers, and a certificate held to a date.",
  },
];

function saveAccounts(email: string, kinds: AccountKind[]) {
  if (kinds.length === 0) return;
  try {
    localStorage.setItem(ACCOUNTS_KEY, JSON.stringify({ email: email.trim().toLowerCase(), kinds }));
  } catch {
    /* the choice still applies to this visit */
  }
}

function readAccounts(email: string): AccountKind[] {
  try {
    const raw = localStorage.getItem(ACCOUNTS_KEY);
    if (!raw) return ["brokerage"];
    const parsed = JSON.parse(raw) as { email?: string; kinds?: AccountKind[] };
    const kinds = (parsed.kinds ?? []).filter((id) => ACCOUNT_TYPES.some((row) => row.id === id));
    if (parsed.email !== email.trim().toLowerCase() || kinds.length === 0) return ["brokerage"];
    return kinds;
  } catch {
    return ["brokerage"];
  }
}

/** Sign-in and new accounts. Letters leave from the firm Outlook mailbox. */
const ACCOUNTS_OPEN = true;

type AccountUser = { name: string; email: string };
type Hold = { email: string; delivered: boolean };

export function ClientApp() {
  const { data } = authClient.useSession();
  const [override, setOverride] = useState<AccountUser | null>(null);
  const [hold, setHold] = useState<Hold | null>(null);
  const sessionUser = data?.user;
  const user = sessionUser ? { name: sessionUser.name, email: sessionUser.email } : override;
  const [admin, setAdmin] = useState(false);
  const [gate, setGate] = useState<"load" | "open" | "verify" | "kyc" | "error">("load");
  const [gateTry, setGateTry] = useState(0);

  useEffect(() => {
    if (!user) {
      setAdmin(false);
      setGate("open");
      return;
    }
    let stop = false;
    setGate("load");
    fetch("/api/me", { headers: authHeaders() })
      .then(async (r) => {
        const body = (await r.json()) as { role?: string; needsVerification?: boolean; needsKyc?: boolean; error?: string };
        if (r.status === 401) return { signedOut: true as const };
        if (!r.ok) throw new Error(body.error || "The account could not be read.");
        return body;
      })
      .then((body) => {
        if (stop) return;
        if ("signedOut" in body) {
          setOverride(null);
          setGate("open");
          return;
        }
        setAdmin(body.role === "admin");
        setGate(body.needsVerification ? "verify" : body.needsKyc ? "kyc" : "open");
      })
      .catch(() => {
        if (!stop) setGate("error");
      });
    return () => {
      stop = true;
    };
  }, [user?.email, gateTry]);

  useEffect(() => {
    if (user && gate === "open") window.scrollTo(0, 0);
  }, [user?.email, gate]);

  if (ACCOUNTS_OPEN && hold && !sessionUser) {
    return <VerifyMail email={hold.email} delivered={hold.delivered} onLeave={() => setHold(null)} />;
  }

  if (!user || (!ACCOUNTS_OPEN && gate !== "open" && gate !== "load" && gate !== "error")) {
    return <Front onSignedIn={setOverride} onHold={setHold} />;
  }

  if (gate === "load") return <Waiting label="One moment" />;
  if (ACCOUNTS_OPEN && gate === "verify") {
    return (
      <VerifyMail
        email={user.email}
        delivered={false}
        autoSend
        onLeave={() => {
          setOverride(null);
          void signOut("/");
        }}
      />
    );
  }
  if (gate === "kyc") {
    return <KycWall onFiled={() => setGateTry((n) => n + 1)} />;
  }
  if (gate === "error") {
    return <Waiting label="The account could not be read." onRetry={() => setGateTry((n) => n + 1)} />;
  }

  return (
    <div className="min-h-screen bg-et-page font-et text-et-ink">
      <BrokerBar name={admin ? "Alpha Clover" : user.name} detail={admin ? FIRM_EMAIL : undefined} admin={admin} />
      <main>
        <div className="mx-auto max-w-6xl px-3 py-3 sm:px-4">
          <Dashboard name={admin ? "Alpha Clover" : user.name} admin={admin} email={user.email} />
        </div>
      </main>
    </div>
  );
}

function Front({
  onSignedIn,
  onHold,
}: {
  onSignedIn: (user: AccountUser) => void;
  onHold: (hold: Hold) => void;
}) {
  const [arrival, setArrival] = useState("");
  const [preferIn, setPreferIn] = useState(false);
  const [preferForgot, setPreferForgot] = useState(false);
  const [resetToken, setResetToken] = useState("");
  const [stage, setStage] = useState<"home" | "types" | "kyc" | "details">("home");
  const [kinds, setKinds] = useState<AccountKind[]>([]);
  const [kyc, setKyc] = useState<KycDraft | null>(null);
  useEffect(() => {
    const url = new URL(window.location.href);
    const token = url.searchParams.get("token") || "";
    if (token) {
      setResetToken(token);
      url.searchParams.delete("token");
      const query = url.searchParams.toString();
      window.history.replaceState(null, "", `${url.pathname}${query ? `?${query}` : ""}${url.hash}`);
      document.getElementById("account")?.scrollIntoView();
      return;
    }
    if (url.searchParams.get("error") && url.searchParams.get("reset") === "1") {
      setArrival("That link has expired. Ask for another.");
      setPreferForgot(true);
    } else if (url.searchParams.get("error")) {
      setArrival("That link has expired. Sign in, and another letter will be sent.");
      setPreferIn(true);
    } else if (url.searchParams.get("verified") === "1") {
      setArrival("The account is confirmed. Sign in.");
      setPreferIn(true);
    }
  }, []);
  if (stage === "types") {
    return (
      <AccountSelect
        kinds={kinds}
        onChange={setKinds}
        onContinue={() => setStage("kyc")}
      />
    );
  }
  if (stage === "kyc") {
    return (
      <div className="min-h-screen bg-et-card font-et text-et-ink">
        <BrokerBar publicNav onOpenAccount={() => setStage("types")} />
        <KycForm
          onBack={() => setStage("types")}
          onFile={(draft) => {
            setKyc(draft);
            setStage("details");
          }}
        />
      </div>
    );
  }
  return (
    <div className="min-h-screen bg-et-page font-et text-et-ink">
      <BrokerBar publicNav onOpenAccount={() => setStage("types")} />

      <section id="top" className="mx-auto grid max-w-6xl items-start gap-8 px-4 py-8 lg:grid-cols-12 lg:py-12">
        <div className="lg:col-span-7">
          <p className="text-sm font-semibold text-et-purple">Discretionary trading</p>
          <h1 className="mt-3 max-w-xl text-4xl font-semibold leading-tight tracking-tight sm:text-5xl">
            The client supplies the capital.
            <span className="mt-1 block">The book supplies the trades.</span>
          </h1>
          <p className="mt-5 max-w-xl text-lg leading-relaxed text-et-muted">
            Alpha Clover accepts a mandate and trades it. Equities, foreign exchange, and major digital assets. One book. No order for the client to place.
          </p>
          <div className="mt-8 grid gap-3 sm:grid-cols-3">
            {[
              ["One percent", "The most that can be risked on a single trade."],
              ["The stop, first", "A stop wider than the rule is refused."],
              ["Ten percent", "Off the peak, the book is flattened."],
            ].map(([title, body]) => (
              <div key={title} className="border border-et-line bg-et-card px-4 py-4">
                <h2 className="text-sm font-semibold">{title}</h2>
                <p className="mt-2 text-sm leading-relaxed text-et-muted">{body}</p>
              </div>
            ))}
          </div>
        </div>
        <div id="account" className="scroll-mt-20 lg:col-span-5">
          {ACCOUNTS_OPEN ? (
            <>
              {arrival ? <p className="mb-3 border border-et-line bg-et-card px-4 py-3 text-sm leading-relaxed">{arrival}</p> : null}
              <AccountForm
                onSignedIn={(user) => {
                  saveAccounts(user.email, kinds);
                  if (kyc) sessionStorage.setItem(KYC_DRAFT, JSON.stringify({ email: user.email.toLowerCase(), ...kyc }));
                  onSignedIn(user);
                }}
                onHold={(hold) => {
                  saveAccounts(hold.email, kinds);
                  if (kyc) sessionStorage.setItem(KYC_DRAFT, JSON.stringify({ email: hold.email.toLowerCase(), ...kyc }));
                  onHold(hold);
                }}
                preferSignIn={preferIn || stage !== "details"}
                preferForgot={preferForgot}
                resetToken={resetToken}
                onBeginOpen={() => setStage("types")}
                opening={ACCOUNT_TYPES.filter((row) => kinds.includes(row.id)).map((row) => row.title)}
              />
            </>
          ) : (
            <div className="border border-et-line bg-et-card p-6">
              <h2 className="text-xl font-semibold">Log on is down.</h2>
              <p className="mt-3 text-sm leading-relaxed text-et-muted">
                New accounts are not being opened, and existing accounts cannot sign in, until a letter can leave the firm again.
              </p>
            </div>
          )}
        </div>
      </section>

      <section id="markets" className="scroll-mt-20 border-t border-et-line bg-et-card">
        <div className="mx-auto max-w-6xl px-4 py-8">
          <h2 className="text-xl font-semibold">Markets the book will take</h2>
          <div className="mt-4 divide-y divide-et-line border border-et-line">
            {[
              ["Equities", "S&P 500, NASDAQ, and the large-cap names. The two indices are never held together."],
              ["Foreign exchange", "Euro, sterling, yen, Swiss franc, Australian dollar, Canadian dollar."],
              ["Digital assets", "Bitcoin, Ether, Solana, and XRP. No smaller coins."],
              ["Metals and energy", "Gold and oil. Each on its own clock."],
            ].map(([title, body]) => (
              <div key={title} className="grid gap-1 px-4 py-3 sm:grid-cols-[12rem_1fr] sm:gap-6">
                <h3 className="text-sm font-semibold">{title}</h3>
                <p className="text-sm leading-relaxed text-et-muted">{body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="firm" className="scroll-mt-20 mx-auto grid max-w-6xl items-center gap-8 px-4 py-10 lg:grid-cols-2">
        <img src="/people/desk.jpg" alt="A woman at her desk" className="h-72 w-full object-cover object-top" />
        <div>
          <h2 className="text-2xl font-semibold leading-tight">A mandate, not a brokerage order ticket.</h2>
          <div className="mt-4 space-y-3 text-sm leading-relaxed text-et-muted">
            <p>The client does not choose the trade. The book does, inside a charter that is already written.</p>
            <p>
              Capital is sent by the client, from a wallet the client already holds. Profit may be withdrawn. Capital stays until the contract ends. A broker fee of twenty percent of that profit is paid before the withdrawal completes.
            </p>
            <p>What is accepted is USDC on Ethereum, USDC on Arbitrum, or ether on Ethereum.</p>
            <a href={`mailto:${FIRM_EMAIL}`} className="inline-block text-et-purple">{FIRM_EMAIL}</a>
          </div>
        </div>
      </section>

      <footer className="bg-et-bar text-et-bar-muted">
        <div className="mx-auto flex max-w-6xl flex-wrap items-end justify-between gap-4 px-4 py-8">
          <div>
            <div className="font-semibold text-et-card">* Alpha Clover</div>
            <p className="mt-2 max-w-sm text-sm">A discretionary book. Equities, foreign exchange, and major digital assets.</p>
          </div>
          <a href={`mailto:${FIRM_EMAIL}`} className="text-sm text-et-card">{FIRM_EMAIL}</a>
        </div>
      </footer>
    </div>
  );
}

function confirmCallback() {
  if (typeof window === "undefined") return "/?verified=1";
  const url = new URL(window.location.href);
  url.search = "";
  url.hash = "";
  url.searchParams.set("verified", "1");
  return url.toString();
}

function resetCallback() {
  if (typeof window === "undefined") return "/?reset=1";
  const url = new URL(window.location.href);
  url.search = "";
  url.hash = "";
  url.searchParams.set("reset", "1");
  return url.toString();
}

async function requestReset(email: string) {
  const client = authClient as unknown as {
    requestPasswordReset: (body: { email: string; redirectTo: string }) => Promise<{
      error: { message?: string; code?: string } | null;
    }>;
  };
  return client.requestPasswordReset({ email, redirectTo: resetCallback() });
}

async function savePassword(newPassword: string, token: string) {
  const client = authClient as unknown as {
    resetPassword: (body: { newPassword: string; token: string }) => Promise<{
      error: { message?: string; code?: string } | null;
    }>;
  };
  return client.resetPassword({ newPassword, token });
}

function mailFailure(error: { message?: string; code?: string } | null | undefined) {
  const message = error?.message || "";
  const code = error?.code || "";
  return /could not be sent|confirmation letter|verification email/i.test(message) || code === "FAILED_TO_SEND";
}

function unverified(error: { message?: string; code?: string; status?: number } | null | undefined) {
  if (!error) return false;
  const message = error.message || "";
  const code = error.code || "";
  return code === "EMAIL_NOT_VERIFIED" || /email not verified/i.test(message) || mailFailure(error);
}

async function sendLetter(email: string) {
  try {
    await sendAccountLetter({ data: { email, callbackURL: confirmCallback() } });
    return { error: null };
  } catch (err) {
    const message = err instanceof Error ? err.message : "The letter could not be sent.";
    return { error: { message } };
  }
}

function VerifyMail({
  email,
  delivered,
  autoSend = false,
  onLeave,
}: {
  email: string;
  delivered: boolean;
  autoSend?: boolean;
  onLeave: () => void;
}) {
  const [busy, setBusy] = useState(false);
  const [phase, setPhase] = useState<"sending" | "sent" | "failed">(
    autoSend ? "sending" : delivered ? "sent" : "failed",
  );
  const [note, setNote] = useState("");

  useEffect(() => {
    if (!autoSend || sentFor.has(email)) return;
    sentFor.add(email);
    void dispatch(true);
  }, [autoSend, email]);

  async function dispatch(quiet: boolean) {
    setBusy(true);
    setPhase("sending");
    if (!quiet) setNote("");
    const result = await sendLetter(email);
    setBusy(false);
    if (result.error || mailFailure(result.error)) {
      setPhase("failed");
      const message = result.error?.message || "";
      setNote(/could not be sent|confirmation letter|verification email/i.test(message) ? "" : message);
      return;
    }
    setPhase("sent");
    setNote(quiet ? "" : "Another letter is on its way.");
  }

  return (
    <div className="min-h-screen bg-et-page font-et text-et-ink">
      <BrokerBar />
      <main className="mx-auto max-w-md px-4 py-10">
        <div className="border border-et-line bg-et-card p-6">
          <h1 className="text-2xl font-semibold">Confirm the address</h1>
          <p className="mt-4 text-sm leading-relaxed text-et-muted">
            {phase === "failed"
              ? "The confirmation letter did not leave. The account stays closed until you open the link in it."
              : phase === "sending"
                ? "Sending the letter to "
                : "A letter was sent to "}
            {phase === "failed" ? null : <span className="font-semibold text-et-ink">{email}</span>}
            {phase === "sent" ? ". Open the link. The account stays closed until you do. The link expires in 24 hours." : null}
            {phase === "sending" ? "." : null}
          </p>
          {phase === "failed" ? <p className="mt-3 text-sm">{email}</p> : null}
          {note ? <p className="mt-4 text-sm leading-relaxed text-et-muted">{note}</p> : null}
          <p className="mt-4 text-sm leading-relaxed text-et-muted">
            {phase === "sent"
              ? `Look in the inbox, and in spam if it is not there. The letter is from ${FIRM_EMAIL}. If you already confirmed this address, sign in instead.`
              : `The letter is sent from ${FIRM_EMAIL}.`}
          </p>
          <button
            type="button"
            disabled={busy}
            onClick={() => void dispatch(false)}
            className="mt-6 w-full rounded-sm bg-et-purple px-3 py-3 text-base font-semibold text-et-card disabled:opacity-50"
          >
            {busy ? "Sending" : phase === "sent" ? "Send the letter again" : "Send the letter"}
          </button>
          <button type="button" onClick={onLeave} className="mt-2 w-full py-3 text-sm text-et-purple">
            Use a different email
          </button>
        </div>
      </main>
    </div>
  );
}

const sentFor = new Set<string>();

function Waiting({ label, onRetry }: { label: string; onRetry?: () => void }) {
  return (
    <div className="grid min-h-screen place-items-center bg-et-page px-6 text-center font-et text-et-ink">
      <div>
        <p className="text-2xl font-semibold">{label}</p>
        {onRetry ? (
          <button type="button" onClick={onRetry} className="mt-6 rounded-sm bg-et-purple px-4 py-3 text-sm font-semibold text-et-card">
            Try again
          </button>
        ) : null}
      </div>
    </div>
  );
}

function AccountForm({
  onSignedIn,
  onHold,
  preferSignIn,
  preferForgot,
  resetToken,
  onBeginOpen,
  opening,
}: {
  onSignedIn: (user: AccountUser) => void;
  onHold: (hold: Hold) => void;
  preferSignIn?: boolean;
  preferForgot?: boolean;
  resetToken?: string;
  onBeginOpen?: () => void;
  opening?: string[];
}) {
  type Mode = "up" | "in" | "forgot" | "reset";
  const [mode, setMode] = useState<Mode>(resetToken ? "reset" : "up");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [note, setNote] = useState("");
  const [token, setToken] = useState(resetToken || "");
  const [busy, setBusy] = useState(false);
  const [live, setLive] = useState(false);
  useEffect(() => setLive(true), []);
  useEffect(() => {
    if (resetToken) {
      setToken(resetToken);
      setMode("reset");
      return;
    }
    if (preferForgot) setMode("forgot");
    else if (preferSignIn) setMode("in");
  }, [resetToken, preferForgot, preferSignIn]);

  function go(next: Mode) {
    setMode(next);
    setError("");
    setNote("");
    setPassword("");
    setConfirm("");
  }

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!live) return;
    const data = new FormData(e.currentTarget);
    const nextName = String(data.get("name") ?? name).trim();
    const nextEmail = String(data.get("email") ?? email).trim();
    const nextPassword = String(data.get("password") ?? password);
    const nextConfirm = String(data.get("confirm") ?? confirm);
    setName(nextName);
    setEmail(nextEmail);
    setPassword(nextPassword);
    setConfirm(nextConfirm);
    setError("");
    setNote("");

    if (mode === "forgot") {
      if (!nextEmail.includes("@")) {
        setError("The letter needs an email.");
        return;
      }
      setBusy(true);
      try {
        const result = await requestReset(nextEmail);
        setBusy(false);
        if (result.error) {
          setError("The letter could not be sent. Try again.");
          return;
        }
        setNote("If an account uses that address, the letter is on its way. It expires in one hour.");
      } catch {
        setBusy(false);
        setError("The letter could not be sent. Try again.");
      }
      return;
    }

    if (mode === "reset") {
      if (nextPassword.length < 8) {
        setError("The password needs eight characters.");
        return;
      }
      if (nextPassword !== nextConfirm) {
        setError("The two passwords do not match.");
        return;
      }
      if (!token) {
        setError("That link has expired. Ask for another.");
        return;
      }
      setBusy(true);
      try {
        const result = await savePassword(nextPassword, token);
        setBusy(false);
        setPassword("");
        setConfirm("");
        if (result.error) {
          const message = result.error.message || "";
          setError(/token|expired/i.test(message) ? "That link has expired. Ask for another." : "That did not work. Try again.");
          return;
        }
        setToken("");
        setMode("in");
        setNote("The password is changed. Sign in.");
      } catch {
        setBusy(false);
        setError("That did not work. Try again.");
      }
      return;
    }

    if (mode === "up" && nextName.length < 2) {
      setError("The account needs a name.");
      return;
    }
    if (nextPassword.length < 8) {
      setError("The password needs eight characters.");
      return;
    }
    setBusy(true);
    try {
      let held: string | null = null;
      const hooks = {
        onSuccess: (ctx: { data?: unknown; response?: Response }) => {
          held = captureSessionToken(ctx);
        },
      };
      const callbackURL = confirmCallback();
      const result =
        mode === "up"
          ? await authClient.signUp.email(
              { name: nextName, email: nextEmail, password: nextPassword, callbackURL },
              hooks,
            )
          : await authClient.signIn.email({ email: nextEmail, password: nextPassword, callbackURL }, hooks);
      if (result.error) {
        if (unverified(result.error)) {
          const sent = await sendLetter(nextEmail);
          setPassword("");
          setBusy(false);
          onHold({ email: nextEmail, delivered: !sent.error });
          return;
        }
        const message = result.error.message || "That did not work.";
        setError(/already exists/i.test(message) ? "That email already has an account. Sign in." : message);
        if (/already exists/i.test(message)) setMode("in");
        setBusy(false);
        return;
      }
      if (!held) captureSessionToken(result);
      const session = await authClient.getSession();
      if (session.data?.user || authHeaders().Authorization) {
        const account = session.data?.user ?? accountFrom(result.data);
        setBusy(false);
        if (!account) {
          setError("The account is open, but this browser did not keep the session. Sign in with the same email.");
          setMode("in");
          return;
        }
        onSignedIn({ name: account.name, email: account.email });
        return;
      }
      const returned = accountFrom(result.data);
      const sent = await sendLetter(returned?.email || nextEmail);
      setPassword("");
      setBusy(false);
      onHold({ email: returned?.email || nextEmail, delivered: !sent.error });
    } catch {
      setBusy(false);
      setError("That did not work. Try again.");
    }
  }

  const title = mode === "up" ? "Open an account" : mode === "in" ? "Log on" : mode === "forgot" ? "Forgot user ID or password" : "New password";
  const action =
    mode === "up" ? "Open an account" : mode === "in" ? "Log on" : mode === "forgot" ? "Send the letter" : "Save the password";

  return (
    <form onSubmit={submit} noValidate className="border border-et-line bg-et-card p-6">
      {mode === "up" || mode === "in" ? (
        <div className="mb-5 flex gap-6 border-b border-et-line text-sm">
          <button type="button" onClick={() => (onBeginOpen ? onBeginOpen() : go("up"))} className={mode === "up" ? "-mb-px border-b-2 border-et-purple pb-2 font-semibold text-et-purple" : "pb-2 text-et-muted"}>
            Open an account
          </button>
          <button type="button" onClick={() => go("in")} className={mode === "in" ? "-mb-px border-b-2 border-et-purple pb-2 font-semibold text-et-purple" : "pb-2 text-et-muted"}>
            Log on
          </button>
        </div>
      ) : (
        <div className="mb-5 flex items-center justify-between gap-3 text-sm">
          <button type="button" onClick={() => go("in")} className="text-et-purple">
            Log on
          </button>
          {mode === "reset" ? (
            <button type="button" onClick={() => go("forgot")} className="text-et-purple">
              Ask for another
            </button>
          ) : null}
        </div>
      )}
      <h2 className="mb-5 text-xl font-semibold">{title}</h2>
      {mode === "up" && opening && opening.length > 0 ? (
        <p className="mb-4 text-sm text-et-muted">Opening {opening.join(", ")}.</p>
      ) : null}
      {mode === "up" ? <Field label="Name" name="name" value={name} onChange={setName} autoComplete="name" /> : null}
      {mode === "reset" ? null : (
        <Field label="Email" name="email" value={email} onChange={setEmail} type="email" autoComplete="email" inputMode="email" />
      )}
      {mode === "forgot" ? null : (
        <Field
          label={mode === "reset" ? "New password" : "Password"}
          name="password"
          value={password}
          onChange={setPassword}
          type="password"
          autoComplete={mode === "in" ? "current-password" : "new-password"}
        />
      )}
      {mode === "reset" ? (
        <Field label="Confirm" name="confirm" value={confirm} onChange={setConfirm} type="password" autoComplete="new-password" />
      ) : null}
      {mode === "in" ? (
        <div className="-mt-1 mb-4 flex justify-end">
          <button type="button" onClick={() => go("forgot")} className="py-2 text-sm text-et-purple">
            Forgot user ID or password
          </button>
        </div>
      ) : null}
      {error ? <p className="mb-3 text-sm text-et-down">{error}</p> : null}
      {note ? <p className="mb-3 text-sm leading-relaxed text-et-muted">{note}</p> : null}
      <button
        type="submit"
        disabled={!live || busy}
        className="w-full rounded-sm bg-et-purple px-3 py-3 text-base font-semibold text-et-card disabled:opacity-50"
      >
        {!live || busy ? "One moment" : action}
      </button>
      <p className="mt-4 text-xs leading-relaxed text-et-muted">
        {mode === "forgot"
          ? "If the address has an account, a letter follows. The link expires in one hour."
          : mode === "reset"
            ? "Eight characters at least. This replaces the password on the account."
            : mode === "in"
              ? "The account stays closed until the confirmation link is opened."
              : "Eight characters at least. We email a link. The account opens when you use it. The firm does not connect to your wallet."}
      </p>
      <p className="mt-3 text-xs leading-relaxed text-et-muted">Letters are sent from {FIRM_EMAIL}.</p>
    </form>
  );
}

const KYC_DRAFT = "alpha-clover.kyc";

type KycDraft = {
  legalName: string;
  dateOfBirth: string;
  citizenship: string;
  residence: string;
  address: string;
  city: string;
  region: string;
  postal: string;
  phone: string;
  employment: string;
  source: string;
  taxId: string;
  taxKind: "" | "ssn" | "tin";
  idType: string;
  idNumber: string;
  pep: "" | "yes" | "no";
};

function kycProblem(draft: KycDraft) {
  if (draft.legalName.trim().length < 2) return "The legal name is required.";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(draft.dateOfBirth)) return "The date of birth is required.";
  const born = new Date(`${draft.dateOfBirth}T00:00:00Z`);
  const adult = new Date();
  adult.setUTCFullYear(adult.getUTCFullYear() - 18);
  if (Number.isNaN(born.getTime()) || born > adult) return "The account holder must be 18 or older.";
  if (draft.citizenship.trim().length < 2) return "Citizenship is required.";
  if (draft.residence.trim().length < 2) return "Country of residence is required.";
  if (draft.address.trim().length < 4) return "The street address is required.";
  if (draft.city.trim().length < 2) return "The city is required.";
  if (draft.region.trim().length < 2) return "The state or region is required.";
  if (draft.postal.trim().length < 2) return "The postal code is required.";
  if (draft.phone.replace(/\D/g, "").length < 7) return "A phone number is required.";
  if (!draft.employment) return "Employment is required.";
  if (!draft.source) return "The source of funds is required.";
  if (!draft.idType) return "The ID type is required.";
  if (draft.idNumber.trim().length < 4) return "The ID number is required.";
  if (draft.taxKind !== "ssn" && draft.taxKind !== "tin") return "Choose SSN or tax ID. Not both.";
  if (draft.taxKind === "ssn" && draft.taxId.replace(/\D/g, "").length !== 9) return "An SSN is nine digits.";
  if (draft.taxKind === "tin" && draft.taxId.trim().length < 4) return "The tax ID is required.";
  if (draft.pep !== "yes" && draft.pep !== "no") return "Say whether you are a politically exposed person.";
  return "";
}

function AccountSelect({
  kinds,
  onChange,
  onContinue,
}: {
  kinds: AccountKind[];
  onChange: (next: AccountKind[]) => void;
  onContinue: () => void;
}) {
  function toggle(id: AccountKind) {
    if (kinds.includes(id)) onChange(kinds.filter((row) => row !== id));
    else onChange([...kinds, id]);
  }

  return (
    <div className="min-h-screen bg-et-card font-et text-et-ink">
      <BrokerBar publicNav />
      <main className="mx-auto max-w-2xl px-5 py-12 sm:py-16">
        <p className="text-center text-sm text-et-muted">Account selection</p>
        <h1 className="mt-3 text-center text-4xl font-semibold tracking-tight sm:text-5xl">Choose account type(s)</h1>
        <p className="mt-3 text-center text-lg text-et-muted">You may choose as many accounts as you'd like.</p>
        <ul className="mt-12">
          {ACCOUNT_TYPES.map((row) => {
            const on = kinds.includes(row.id);
            return (
              <li key={row.id} className="border-b-2 border-et-purple py-5">
                <button type="button" onClick={() => toggle(row.id)} className="flex w-full gap-3 text-left" aria-pressed={on}>
                  <span className={`mt-0.5 grid size-6 shrink-0 place-items-center rounded-sm ${on ? "bg-et-purple text-et-card" : "border border-et-line bg-et-card"}`}>
                    {on ? <Check className="size-4" strokeWidth={3} /> : null}
                  </span>
                  <span>
                    <span className="flex flex-wrap items-center gap-2">
                      <span className="text-lg font-semibold text-et-purple">{row.title}</span>
                      {row.badge ? <span className="border border-et-ink px-1.5 py-0.5 text-xs text-et-ink">{row.badge}</span> : null}
                    </span>
                    <span className="mt-1 block text-base leading-relaxed text-et-muted">{row.body}</span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
        <p className="mt-6 text-sm leading-relaxed text-et-muted">
          Cash at Alpha Clover is held by the firm. It is not a bank deposit, and it is not FDIC insured.
        </p>
        <button
          type="button"
          disabled={kinds.length === 0}
          onClick={onContinue}
          className="mt-8 w-full rounded-sm bg-et-purple py-3.5 text-lg font-semibold text-et-card disabled:opacity-50"
        >
          Continue
        </button>
      </main>
    </div>
  );
}

function KycForm({
  onFile,
  onBack,
}: {
  onFile: (draft: KycDraft) => void | Promise<void>;
  onBack?: () => void;
}) {
  const [draft, setDraft] = useState<KycDraft>({
    legalName: "",
    dateOfBirth: "",
    citizenship: "",
    residence: "",
    address: "",
    city: "",
    region: "",
    postal: "",
    phone: "",
    employment: "",
    source: "",
    taxId: "",
    taxKind: "",
    idType: "",
    idNumber: "",
    pep: "",
  });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  function set<K extends keyof KycDraft>(key: K, value: KycDraft[K]) {
    setDraft((current) => ({ ...current, [key]: value }));
  }

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const problem = kycProblem(draft);
    if (problem) {
      setError(problem);
      return;
    }
    setError("");
    setBusy(true);
    try {
      await onFile(draft);
    } catch (err) {
      setError(err instanceof Error ? err.message : "The identity form was not filed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto max-w-2xl px-5 py-12 sm:py-16">
      <p className="text-center text-sm text-et-muted">Identity</p>
      <h1 className="mt-3 text-center text-4xl font-semibold tracking-tight sm:text-5xl">Know your customer</h1>
      <p className="mt-3 text-center text-lg text-et-muted">Required. The account stays closed until this is filed.</p>
      <form onSubmit={submit} noValidate className="mt-10 grid gap-3">
        <Field label="Legal name" name="legalName" value={draft.legalName} onChange={(v) => set("legalName", v)} autoComplete="name" />
        <Field label="Date of birth" name="dob" value={draft.dateOfBirth} onChange={(v) => set("dateOfBirth", v)} type="date" autoComplete="bday" />
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Citizenship" name="citizenship" value={draft.citizenship} onChange={(v) => set("citizenship", v)} autoComplete="country-name" />
          <Field label="Country of residence" name="residence" value={draft.residence} onChange={(v) => set("residence", v)} autoComplete="country-name" />
        </div>
        <Field label="Street address" name="address" value={draft.address} onChange={(v) => set("address", v)} autoComplete="street-address" />
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="City" name="city" value={draft.city} onChange={(v) => set("city", v)} autoComplete="address-level2" />
          <Field label="State or region" name="region" value={draft.region} onChange={(v) => set("region", v)} autoComplete="address-level1" />
          <Field label="Postal code" name="postal" value={draft.postal} onChange={(v) => set("postal", v)} autoComplete="postal-code" />
        </div>
        <Field label="Phone" name="phone" value={draft.phone} onChange={(v) => set("phone", v)} type="tel" autoComplete="tel" />
        <label className="block">
          <span className="mb-1 block text-xs font-semibold text-et-muted">Employment</span>
          <select
            required
            value={draft.employment}
            onChange={(e) => set("employment", e.target.value)}
            className="w-full rounded-sm border border-et-line bg-et-card px-3 py-2.5 text-base text-et-ink outline-none focus:border-et-purple"
          >
            <option value="">Select</option>
            <option value="employed">Employed</option>
            <option value="self-employed">Self-employed</option>
            <option value="retired">Retired</option>
            <option value="student">Student</option>
            <option value="unemployed">Unemployed</option>
          </select>
        </label>
        <label className="block">
          <span className="mb-1 block text-xs font-semibold text-et-muted">Source of funds</span>
          <select
            required
            value={draft.source}
            onChange={(e) => set("source", e.target.value)}
            className="w-full rounded-sm border border-et-line bg-et-card px-3 py-2.5 text-base text-et-ink outline-none focus:border-et-purple"
          >
            <option value="">Select</option>
            <option value="salary">Salary</option>
            <option value="savings">Savings</option>
            <option value="business">Business</option>
            <option value="investment">Investment</option>
            <option value="other">Other</option>
          </select>
        </label>
        <label className="block">
          <span className="mb-1 block text-xs font-semibold text-et-muted">ID</span>
          <select
            required
            value={draft.idType}
            onChange={(e) => set("idType", e.target.value)}
            className="w-full rounded-sm border border-et-line bg-et-card px-3 py-2.5 text-base text-et-ink outline-none focus:border-et-purple"
          >
            <option value="">Select</option>
            <option value="passport">Passport</option>
            <option value="national">National ID</option>
            <option value="driver">Driver's license</option>
          </select>
        </label>
        <Field label="ID number" name="idNumber" value={draft.idNumber} onChange={(v) => set("idNumber", v)} autoComplete="off" />
        <label className="block">
          <span className="mb-1 block text-xs font-semibold text-et-muted">Taxpayer number</span>
          <select
            required
            value={draft.taxKind}
            onChange={(e) => set("taxKind", e.target.value as KycDraft["taxKind"])}
            className="w-full rounded-sm border border-et-line bg-et-card px-3 py-2.5 text-base text-et-ink outline-none focus:border-et-purple"
          >
            <option value="">Select one</option>
            <option value="ssn">SSN</option>
            <option value="tin">Tax ID</option>
          </select>
        </label>
        <Field
          label={draft.taxKind === "tin" ? "Tax ID" : "SSN"}
          name="taxId"
          value={draft.taxId}
          onChange={(v) => set("taxId", v)}
          autoComplete="off"
        />
        <fieldset className="mt-1">
          <legend className="mb-2 text-xs font-semibold text-et-muted">Are you a politically exposed person?</legend>
          <div className="flex gap-6 text-sm">
            <label className="flex items-center gap-2">
              <input type="radio" name="pep" checked={draft.pep === "yes"} onChange={() => set("pep", "yes")} />
              Yes
            </label>
            <label className="flex items-center gap-2">
              <input type="radio" name="pep" checked={draft.pep === "no"} onChange={() => set("pep", "no")} />
              No
            </label>
          </div>
        </fieldset>
        {error ? <p className="text-sm text-et-down">{error}</p> : null}
        <button type="submit" disabled={busy} className="mt-2 w-full rounded-sm bg-et-purple py-3.5 text-lg font-semibold text-et-card disabled:opacity-50">
          {busy ? "Filing" : "File identity"}
        </button>
        {onBack ? (
          <button type="button" onClick={onBack} className="w-full py-2 text-sm text-et-purple">
            Back to account types
          </button>
        ) : null}
        <p className="text-xs leading-relaxed text-et-muted">
          One taxpayer number. SSN for a US person. A tax ID if not. The ID above is the passport, national ID, or license. Neither number is shown again.
        </p>
      </form>
    </main>
  );
}

function KycWall({ onFiled }: { onFiled: () => void }) {
  const [error, setError] = useState("");
  const [filing, setFiling] = useState(false);
  const onFiledRef = useRef(onFiled);
  onFiledRef.current = onFiled;

  useEffect(() => {
    const raw = sessionStorage.getItem(KYC_DRAFT);
    if (!raw) return;
    let draft: (KycDraft & { email?: string }) | null = null;
    try {
      draft = JSON.parse(raw) as KycDraft & { email?: string };
    } catch {
      sessionStorage.removeItem(KYC_DRAFT);
      return;
    }
    if (!draft || kycProblem(draft)) return;
    let stop = false;
    setFiling(true);
    api("/api/kyc", {
      method: "POST",
      body: JSON.stringify({ ...draft, pep: draft.pep === "yes" }),
    })
      .then(async (r) => {
        const body = (await r.json()) as { error?: string };
        if (stop) return;
        if (!r.ok) {
          setFiling(false);
          setError(body.error || "The identity form was not filed.");
          return;
        }
        sessionStorage.removeItem(KYC_DRAFT);
        onFiledRef.current();
      })
      .catch(() => {
        if (!stop) {
          setFiling(false);
          setError("The identity form was not filed.");
        }
      });
    return () => {
      stop = true;
    };
  }, []);

  if (filing) {
    return (
      <div className="min-h-screen bg-et-card font-et text-et-ink">
        <BrokerBar name="Identity" />
        <p className="px-5 py-16 text-center text-lg">Filing the identity form.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-et-card font-et text-et-ink">
      <BrokerBar name="Identity" />
      {error ? <p className="mx-auto max-w-2xl px-5 pt-6 text-sm text-et-down">{error}</p> : null}
      <KycForm
        onFile={async (draft) => {
          const res = await api("/api/kyc", {
            method: "POST",
            body: JSON.stringify({ ...draft, pep: draft.pep === "yes" }),
          });
          const body = (await res.json()) as { error?: string };
          if (!res.ok) throw new Error(body.error || "The identity form was not filed.");
          sessionStorage.removeItem(KYC_DRAFT);
          onFiled();
        }}
      />
    </div>
  );
}

function accountFrom(data: unknown): AccountUser | null {
  if (!data || typeof data !== "object") return null;
  const user = "user" in data ? (data as { user?: unknown }).user : data;
  if (!user || typeof user !== "object") return null;
  const name = "name" in user && typeof user.name === "string" ? user.name : "";
  const email = "email" in user && typeof user.email === "string" ? user.email : "";
  if (!email) return null;
  return { name, email };
}

function Field({
  label,
  name,
  value,
  onChange,
  type = "text",
  autoComplete,
  inputMode,
}: {
  label: string;
  name: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  autoComplete: string;
  inputMode?: "email" | "text";
}) {
  return (
    <label className="mb-3 block">
      <span className="mb-1 block text-xs font-semibold text-et-muted">{label}</span>
      <input
        required
        name={name}
        type={type}
        value={value}
        autoComplete={autoComplete}
        autoCapitalize="none"
        autoCorrect="off"
        spellCheck={false}
        inputMode={inputMode}
        enterKeyHint="go"
        onChange={(e) => onChange(e.target.value)}
        onInput={(e) => onChange((e.target as HTMLInputElement).value)}
        className="w-full rounded-sm border border-et-line bg-et-card px-3 py-2.5 text-base text-et-ink outline-none focus:border-et-purple"
      />
    </label>
  );
}

function api(path: string, init?: RequestInit) {
  const headers = new Headers(init?.headers);
  const auth = authHeaders();
  if (auth.Authorization) headers.set("Authorization", auth.Authorization);
  if (init?.body && !headers.has("content-type")) headers.set("content-type", "application/json");
  return fetch(path, { ...init, headers });
}

type Letter = { id: string; subject: string; body: string; createdAt: string };

function PostBox() {
  const [letters, setLetters] = useState<Letter[] | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api("/api/post")
      .then(async (r) => {
        const body = (await r.json()) as { letters?: Letter[]; error?: string };
        if (!r.ok) throw new Error(body.error || "The box did not open.");
        setLetters(body.letters ?? []);
      })
      .catch((err: unknown) => setError(err instanceof Error ? err.message : "The box did not open."));
  }, []);

  return (
    <section className="border border-et-line bg-et-card">
      <div className="flex items-baseline justify-between gap-3 border-b border-et-line px-4 py-3">
        <h2 className="text-sm font-semibold">Messages</h2>
        <span className="font-data text-xs text-et-muted">{letters ? `${letters.length} filed` : "…"}</span>
      </div>
      {error ? <p className="px-4 py-4 text-sm text-et-down">{error}</p> : null}
      {letters && letters.length === 0 ? <p className="px-4 py-4 text-sm text-et-muted">Nothing is filed yet.</p> : null}
      <ul className="divide-y divide-et-line">
        {(letters ?? []).map((letter) => (
          <li key={letter.id} className="px-4 py-4">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <h3 className="text-sm font-semibold">{letter.subject}</h3>
              <time className="font-data text-xs text-et-muted" dateTime={letter.createdAt}>
                {new Date(letter.createdAt).toLocaleString("en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}
              </time>
            </div>
            <p className="mt-2 max-w-3xl text-sm leading-relaxed text-et-muted">{letter.body}</p>
          </li>
        ))}
      </ul>
    </section>
  );
}
function RetirementAccount({ name }: { name: string }) {
  return (
    <section className="border border-et-line bg-et-card px-4 py-4">
      <p className="text-xs font-semibold tracking-wide text-et-muted uppercase">Retirement · {name}</p>
      <div className="mt-2 font-data text-4xl font-semibold tracking-tight">{usd(0)}</div>
      <p className="mt-2 max-w-xl text-sm text-et-muted">No capital in this account yet. The book does not trade an empty retirement mandate.</p>
      <ul className="mt-6 divide-y divide-et-line border-y border-et-line">
        {[
          ["Traditional", "Pre-tax capital. The book trades it until the date on the mandate."],
          ["Roth", "After-tax capital. The same book, the same charter."],
          ["SEP", "A retirement mandate for self-employed capital."],
          ["Rollover", "Capital moved in from an existing retirement account."],
        ].map(([title, body]) => (
          <li key={title} className="grid gap-1 py-3 sm:grid-cols-[10rem_1fr]">
            <span className="text-sm font-semibold text-et-purple">{title}</span>
            <span className="text-sm text-et-muted">{body}</span>
          </li>
        ))}
      </ul>
      <p className="mt-4 text-sm text-et-muted">Send capital to the firm address and mark the transfer Retirement. Alpha Clover is not a tax custodian.</p>
      <p className="mt-2 break-all font-data text-xs">{FUNDING_WALLET}</p>
    </section>
  );
}

function CashAccounts() {
  return (
    <section className="border border-et-line bg-et-card px-4 py-4">
      <p className="text-xs font-semibold tracking-wide text-et-muted uppercase">Savings, checking, and CD</p>
      <div className="mt-2 font-data text-4xl font-semibold tracking-tight">{usd(0)}</div>
      <p className="mt-2 max-w-xl text-sm text-et-muted">No cash has been received. A rate is shown here only after the firm sets one.</p>
      <ul className="mt-6 divide-y divide-et-line border-y border-et-line">
        {[
          ["Savings", "Cash held at the firm. Not a bank deposit."],
          ["Checking", "The balance transfers move through."],
          ["Certificate of deposit", "Held to a date. No certificate is open."],
        ].map(([title, body]) => (
          <li key={title} className="flex flex-wrap items-baseline justify-between gap-3 py-3">
            <div>
              <div className="text-sm font-semibold text-et-purple">{title}</div>
              <div className="text-sm text-et-muted">{body}</div>
            </div>
            <div className="font-data text-sm">{usd(0)}</div>
          </li>
        ))}
      </ul>
      <p className="mt-4 text-sm text-et-muted">Cash at Alpha Clover is held by the firm. It is not a bank deposit, and it is not FDIC insured.</p>
    </section>
  );
}

function Dashboard({ name, admin, email }: { name: string; admin: boolean; email: string }) {
  const [book, setBook] = useState<OperatorState | null>(null);
  const [copied, setCopied] = useState(false);
  const kinds = readAccounts(email);
  const [account, setAccount] = useState<AccountKind>(kinds[0] ?? "brokerage");

  useEffect(() => subscribeBook((view) => setBook(view.book)), []);

  async function copy() {
    try {
      await navigator.clipboard.writeText(FUNDING_WALLET);
      setCopied(true);
    } catch {
      setCopied(false);
    }
  }

  const firm = book ? (book.bankroll ?? 0) + (book.cryptoBook ?? 0) : 0;
  const openPnl = book?.positions?.reduce((a, p) => a + p.unrealR * p.riskUsd, 0) ?? 0;
  const realized = book?.closed?.reduce((a, c) => a + c.pnl, 0) ?? 0;
  const peak = book ? (book.peak ?? 0) + (book.cryptoPeak ?? 0) : 0;
  const dd = peak > 0 ? Math.max(0, (peak - firm) / peak) : 0;
  const path = book?.equity
    ? book.equity.map((v, i) => v + (book.cryptoEquity[Math.min(i, book.cryptoEquity.length - 1)] ?? 0))
    : [];

  return (
    <div className="grid gap-3">
      {kinds.length > 1 ? (
        <div className="flex flex-wrap gap-2">
          {ACCOUNT_TYPES.filter((row) => kinds.includes(row.id)).map((row) => (
            <button
              key={row.id}
              type="button"
              onClick={() => setAccount(row.id)}
              className={`rounded-sm px-3 py-2 text-sm font-semibold ${account === row.id ? "bg-et-purple text-et-card" : "border border-et-line bg-et-card text-et-ink"}`}
            >
              {row.title}
            </button>
          ))}
        </div>
      ) : null}
      {account === "retirement" ? <RetirementAccount name={name} /> : null}
      {account === "cash" ? <CashAccounts /> : null}
      {account === "brokerage" ? (
      <>
      <section className="border border-et-line bg-et-card px-4 py-4">
        <p className="text-xs font-semibold tracking-wide text-et-muted uppercase">
          {admin ? "Brokerage · Admin" : "Brokerage"} · {name}
        </p>
        <div className="mt-2 flex flex-wrap items-end justify-between gap-4">
          <div>
            <div className="font-data text-4xl font-semibold tracking-tight">{usd(firm)}</div>
            <p className={`mt-1 font-data text-sm ${openPnl < 0 ? "text-et-down" : "text-et-up"}`}>{signedUsd(openPnl)} open</p>
            <p className="mt-2 max-w-xl text-sm text-et-muted">
              Capital stays until the contract ends. Only profit can be withdrawn, and only after the broker fee.
            </p>
          </div>
          <div className="w-40">
            <Spark values={path} up={path.length < 2 || path[path.length - 1] >= path[0]} always />
          </div>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-px border-t border-et-line bg-et-line sm:grid-cols-4">
          {[
            ["Core book", usd(book?.bankroll ?? 0), ""],
            ["Crypto book", usd(book?.cryptoBook ?? 0), ""],
            ["Open P&L", signedUsd(openPnl), openPnl < 0 ? "text-et-down" : "text-et-up"],
            ["From peak", `${(dd * 100).toFixed(1)}%`, ""],
          ].map(([k, v, tone]) => (
            <div key={k} className="bg-et-card px-3 py-3">
              <div className="text-xs text-et-muted">{k}</div>
              <div className={`mt-1 font-data text-lg ${tone}`}>{v}</div>
            </div>
          ))}
        </div>
      </section>

      <TerminalChart tone="broker" />

      <section id="positions" className="scroll-mt-16 border border-et-line bg-et-card">
        <div className="flex items-baseline justify-between gap-3 border-b border-et-line px-4 py-3">
          <h2 className="text-sm font-semibold">Positions</h2>
          <span className="font-data text-xs text-et-muted">{book ? `${book.positions.length} open` : "…"}</span>
        </div>
        <div className="hidden grid-cols-[1fr_6rem_6rem_6rem] gap-2 px-4 py-2 text-xs font-semibold text-et-muted sm:grid">
          <span>Symbol</span>
          <span>Last</span>
          <span className="text-right">Side</span>
          <span className="text-right">Open P&L</span>
        </div>
        <ul className="divide-y divide-et-line">
          {(book?.markets ?? []).map((m) => {
            const held = book?.positions.filter((p) => p.market === m.id) ?? [];
            const pnl = held.reduce((a, p) => a + p.unrealR * p.riskUsd, 0);
            return (
              <li key={m.id} className="grid items-center gap-2 px-4 py-3 sm:grid-cols-[1fr_6rem_6rem_6rem]">
                <div>
                  <div className="text-sm font-semibold">{m.label}</div>
                  <div className="text-xs text-et-muted">{held.length === 0 ? "Flat" : held.map((p) => p.name).join(", ")}</div>
                </div>
                <div className="font-data text-sm">{Number.isFinite(m.quote) ? formatDesk(m.quote as number) : "—"}</div>
                <div className="text-xs text-et-muted sm:text-right">
                  {held.length === 0 ? "—" : held.map((p) => (p.side === "LONG" ? "Long" : "Short")).join(", ")}
                </div>
                <div className={`text-right font-data text-sm ${held.length === 0 ? "text-et-muted" : pnl >= 0 ? "text-et-up" : "text-et-down"}`}>
                  {held.length === 0 ? "—" : signedUsd(pnl)}
                </div>
              </li>
            );
          })}
          {book ? null : <li className="px-4 py-6 text-sm text-et-muted">Loading the book.</li>}
        </ul>
      </section>

      <section id="activity" className="scroll-mt-16 border border-et-line bg-et-card">
        <div className="flex items-baseline justify-between gap-3 border-b border-et-line px-4 py-3">
          <h2 className="text-sm font-semibold">Activity</h2>
          <span className="font-data text-xs text-et-muted">Closed trades</span>
        </div>
        <div className="hidden grid-cols-[1fr_5.5rem_5.5rem_5.5rem] gap-2 px-4 py-2 text-xs font-semibold text-et-muted sm:grid">
          <span>Market</span>
          <span className="text-right">Earned</span>
          <span className="text-right">Lost</span>
          <span className="text-right">Net</span>
        </div>
        <ul className="divide-y divide-et-line">
          {(book?.markets ?? []).map((m) => {
            const row = book?.ledger[m.id] ?? { earned: 0, lost: 0 };
            const net = row.earned - row.lost;
            return (
              <li key={m.id} className="px-4 py-3 sm:grid sm:grid-cols-[1fr_5.5rem_5.5rem_5.5rem] sm:items-baseline sm:gap-2">
                <span className="text-sm">{m.label}</span>
                <div className="mt-2 grid grid-cols-3 gap-2 sm:contents">
                  <span className={`font-data text-sm sm:text-right ${row.earned > 0 ? "text-et-up" : "text-et-muted"}`}>{usd(row.earned)}</span>
                  <span className={`font-data text-sm sm:text-right ${row.lost > 0 ? "text-et-down" : "text-et-muted"}`}>{usd(row.lost)}</span>
                  <span className={`text-right font-data text-sm ${net > 0 ? "text-et-up" : net < 0 ? "text-et-down" : "text-et-muted"}`}>{signedUsd(net)}</span>
                </div>
              </li>
            );
          })}
        </ul>
        {book ? (
          <div className="grid grid-cols-3 gap-2 border-t border-et-line px-4 py-3 text-sm sm:grid-cols-[1fr_5.5rem_5.5rem_5.5rem]">
            <span className="col-span-3 font-semibold sm:col-span-1">Book</span>
            <span className="font-data text-et-up sm:text-right">{usd(book.markets.reduce((a, m) => a + book.ledger[m.id].earned, 0))}</span>
            <span className="font-data text-et-down sm:text-right">{usd(book.markets.reduce((a, m) => a + book.ledger[m.id].lost, 0))}</span>
            <span className={`text-right font-data ${book.markets.reduce((a, m) => a + book.ledger[m.id].earned - book.ledger[m.id].lost, 0) >= 0 ? "text-et-up" : "text-et-down"}`}>
              {signedUsd(book.markets.reduce((a, m) => a + book.ledger[m.id].earned - book.ledger[m.id].lost, 0))}
            </span>
          </div>
        ) : null}
        <p className="border-t border-et-line px-4 py-3 text-xs text-et-muted">An open position is not earned and not lost until it closes. The book places the trade. There is no order ticket.</p>
      </section>

      <div id="transfer" className="scroll-mt-16 grid items-start gap-3 lg:grid-cols-12">
        <div className="lg:col-span-8">
          <Withdraw realized={realized} />
        </div>
        <div className="grid gap-3 lg:col-span-4">
          <div className="border border-et-line bg-et-card p-4">
            <div className="text-xs font-semibold tracking-wide text-et-muted uppercase">Transfer in</div>
            <img src="/funding-qr.jpg" alt="QR code for the firm funding address" width={160} height={160} className="mx-auto mt-3 h-40 w-40 bg-et-card p-1" />
            <p className="mt-3 break-all font-data text-xs leading-relaxed">{FUNDING_WALLET}</p>
            <button type="button" onClick={copy} className="mt-3 rounded-sm bg-et-purple px-3 py-2 text-sm font-semibold text-et-card">
              {copied ? "Copied" : "Copy address"}
            </button>
            <ul className="mt-4 space-y-1 text-xs text-et-muted">
              <li>USDC on Ethereum</li>
              <li>USDC on Arbitrum</li>
              <li>ETH on Ethereum</li>
            </ul>
          </div>
          <div className="border border-et-line bg-et-card p-4">
            <h2 className="text-xs font-semibold tracking-wide text-et-muted uppercase">Sleeves</h2>
            <ul className="mt-3 space-y-3">
              {MARKETS.map(([market, tf, line]) => (
                <li key={market}>
                  <div className="flex items-baseline justify-between gap-3 text-sm">
                    <span className="font-semibold">{market}</span>
                    <span className="font-data text-xs text-et-muted">{tf}</span>
                  </div>
                  <div className="text-xs text-et-muted">{line}</div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <PostBox />
      </>
      ) : null}
    </div>
  );
}

type MandateView = {
  capital: number;
  contractEnds: string;
  status: "idle" | "fee_due";
  pendingProfit: number;
  pendingFee: number;
  pendingNet: number;
  withdrawn: number;
};

function Withdraw({ realized }: { realized: number }) {
  const [mandate, setMandate] = useState<MandateView | null>(null);
  const [error, setError] = useState("");
  const [receipt, setReceipt] = useState("");
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    api("/api/mandate")
      .then((r) => r.json())
      .then((body: MandateView) => setMandate(body))
      .catch(() => setError("The mandate did not load."));
  }, []);

  const withdrawn = mandate?.withdrawn ?? 0;
  const withdrawable = Math.max(0, Math.round((realized - withdrawn) * 100) / 100);
  const quote = feeOn(Math.max(withdrawable, 0));
  const ends = mandate
    ? new Date(mandate.contractEnds).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })
    : "…";

  async function post(body: { action: string; amount?: number; realized?: number }) {
    setBusy(true);
    setError("");
    const res = await api("/api/mandate", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = (await res.json()) as MandateView & { error?: string; mandate?: MandateView; fee?: number; released?: number };
    setBusy(false);
    if (data.mandate) setMandate(data.mandate);
    if (!res.ok) {
      setError(data.error || "That did not go through.");
      return;
    }
    if (body.action === "pay") setReceipt(`Broker fee of ${usd(data.fee ?? 0)} is paid. ${usd(data.released ?? 0)} of profit is released.`);
    if (body.action === "withdraw") setReceipt("");
  }

  async function copyFee() {
    try {
      await navigator.clipboard.writeText(FUNDING_WALLET);
      setCopied(true);
    } catch {
      setCopied(false);
    }
  }

  return (
    <section className="border border-et-line bg-et-card">
      <div className="flex flex-wrap items-baseline justify-between gap-3 border-b border-et-line px-4 py-3">
        <h2 className="text-sm font-semibold">Transfer out</h2>
        <span className="font-data text-xs text-et-muted">Broker fee {(BROKER_FEE * 100).toFixed(0)}% of profit</span>
      </div>
      <div className="grid gap-px bg-et-line sm:grid-cols-3">
        <div className="bg-et-card px-4 py-3">
          <div className="text-xs text-et-muted">Capital</div>
          <div className="mt-1 font-data text-lg">{usd(mandate?.capital ?? 0)}</div>
          <p className="mt-1 text-xs text-et-muted">Locked until {ends}.</p>
        </div>
        <div className="bg-et-card px-4 py-3">
          <div className="text-xs text-et-muted">Profit you can take</div>
          <div className={`mt-1 font-data text-lg ${withdrawable > 0 ? "text-et-up" : ""}`}>{usd(withdrawable)}</div>
          <p className="mt-1 text-xs text-et-muted">Realized result {signedUsd(realized)}. Open trades are not profit yet.</p>
        </div>
        <div className="bg-et-card px-4 py-3">
          <div className="text-xs text-et-muted">Broker fee if you withdraw it</div>
          <div className="mt-1 font-data text-lg">{withdrawable > 0 ? usd(quote.fee) : "—"}</div>
          <p className="mt-1 text-xs text-et-muted">{withdrawable > 0 ? `${usd(quote.net)} would be released after the fee.` : "No fee until there is a profit."}</p>
        </div>
      </div>
      <div className="grid gap-4 px-4 py-4">
        {mandate?.status === "fee_due" ? (
          <div className="border border-et-line bg-et-page p-4">
            <p className="text-sm">The withdrawal is not complete. Pay the broker fee first.</p>
            <p className="mt-3 font-data text-2xl">{usd(mandate.pendingFee)}</p>
            <p className="mt-1 text-xs text-et-muted">
              On a profit of {usd(mandate.pendingProfit)}. After the fee, {usd(mandate.pendingNet)} is released. Send the fee to the firm address. The desk does not pull it.
            </p>
            <img src="/funding-qr.jpg" alt="QR code for the broker fee" width={128} height={128} className="mt-3 h-32 w-32 bg-et-card p-1" />
            <p className="mt-3 break-all font-data text-xs">{FUNDING_WALLET}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <button type="button" onClick={copyFee} className="rounded-sm border border-et-line px-3 py-2 text-sm">
                {copied ? "Copied" : "Copy address"}
              </button>
              <button type="button" disabled={busy} onClick={() => void post({ action: "pay" })} className="rounded-sm bg-et-purple px-3 py-2 text-sm font-semibold text-et-card disabled:opacity-50">
                {busy ? "Working" : "I have paid the fee"}
              </button>
            </div>
          </div>
        ) : (
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              disabled={busy || withdrawable <= 0 || !mandate}
              onClick={() => void post({ action: "withdraw", amount: withdrawable, realized })}
              className="rounded-sm bg-et-purple px-3 py-2 text-sm font-semibold text-et-card disabled:opacity-50"
            >
              Withdraw profits
            </button>
            <button type="button" disabled={busy || !mandate} onClick={() => void post({ action: "capital" })} className="rounded-sm border border-et-line px-3 py-2 text-sm disabled:opacity-50">
              Withdraw capital
            </button>
          </div>
        )}
        {error ? <p className="text-sm text-et-down">{error}</p> : null}
        {receipt ? <p className="text-sm text-et-up">{receipt}</p> : null}
      </div>
    </section>
  );
}

function Spark({ values, up, always }: { values: number[]; up: boolean; always?: boolean }) {
  const w = 120;
  const h = 32;
  if (values.length < 2) return <span className={always ? "block" : "hidden sm:block"} />;
  const min = Math.min(...values);
  const span = Math.max(...values) - min || 1;
  const d = values
    .map((v, i) => {
      const x = (i / (values.length - 1)) * w;
      const y = h - ((v - min) / span) * 28 - 2;
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className={`${always ? "block" : "hidden sm:block"} h-8 w-full`} aria-hidden>
      <path d={d} className={`${up ? "stroke-et-up" : "stroke-et-down"} fill-none`} strokeWidth="1.6" />
    </svg>
  );
}

function BrokerBar({
  name,
  detail,
  admin,
  publicNav,
  onOpenAccount,
}: {
  name?: string;
  detail?: string;
  admin?: boolean;
  publicNav?: boolean;
  onOpenAccount?: () => void;
}) {
  return (
    <header className="sticky top-0 z-20 bg-et-bar font-et text-et-card">
      <div className="mx-auto flex h-14 max-w-6xl items-center gap-4 px-4">
        <a href={publicNav ? "#top" : "/"} className="flex shrink-0 items-baseline gap-1 text-base font-semibold tracking-tight">
          <span className="text-lg font-bold text-et-purple">*</span>
          <span>Alpha Clover</span>
        </a>
        {publicNav ? (
          <nav className="ml-auto flex items-center gap-4 text-sm sm:gap-6">
            <a href="#markets" className="hidden text-et-bar-muted sm:inline">Markets</a>
            <a href="#firm" className="hidden text-et-bar-muted md:inline">The firm</a>
            <a href="/desk" className="hidden text-et-bar-muted sm:inline">Operator</a>
            {onOpenAccount ? (
              <button type="button" onClick={onOpenAccount} className="rounded-sm bg-et-purple px-3 py-2 font-semibold text-et-card">
                Open an account
              </button>
            ) : (
              <a href="#account" className="rounded-sm bg-et-purple px-3 py-2 font-semibold text-et-card">Open an account</a>
            )}
          </nav>
        ) : name ? (
          <nav className="ml-auto flex items-center gap-3 text-sm sm:gap-5">
            <a href="#positions" className="hidden text-et-card sm:inline">Positions</a>
            <a href="#activity" className="hidden text-et-bar-muted sm:inline">Activity</a>
            <a href="#transfer" className="hidden text-et-bar-muted md:inline">Transfer</a>
            <a href="/desk" className="hidden text-et-bar-muted lg:inline">Operator</a>
            <span className="hidden text-right text-et-bar-muted sm:block">
              <span className="block text-et-card">
                {name}
                {admin ? " · Admin" : ""}
              </span>
              {detail ? <span className="block max-w-48 truncate text-xs">{detail}</span> : null}
            </span>
            <button type="button" onClick={() => void signOut("/")} className="rounded-sm border border-et-bar-muted px-3 py-1.5 text-et-card">
              Log off
            </button>
          </nav>
        ) : null}
      </div>
    </header>
  );
}

function usd(n: number) {
  return n.toLocaleString("en-US", { style: "currency", currency: "USD" });
}

function signedUsd(n: number) {
  const body = usd(Math.abs(n));
  if (n > 0) return `+${body}`;
  if (n < 0) return `-${body}`;
  return body;
}
