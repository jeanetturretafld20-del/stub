export function PageLoading() {
  return (
    <div className="grid min-h-screen place-items-center bg-[#070a08]" role="status" aria-live="polite">
      <div className="flex flex-col items-center gap-6">
        <div className="clover-load" aria-hidden>
          <span />
          <span />
          <span />
          <span />
          <i />
        </div>
        <p className="font-data text-[11px] tracking-[0.32em] text-[#8d9a92] uppercase">Opening</p>
      </div>
    </div>
  );
}
