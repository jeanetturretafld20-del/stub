import { createRouter } from "@tanstack/react-router";
import { PageLoading } from "@/components/page-loading";
import { AppErrorComponent } from "@/lib/error-component";
import { previewPathRewrite } from "@/lib/preview-path-prefix";
import { routeTree } from "./routeTree.gen";

export function getRouter() {
  return createRouter({
    routeTree,
    rewrite: previewPathRewrite(),
    defaultErrorComponent: AppErrorComponent,
    defaultPendingComponent: PageLoading,
    defaultPendingMs: 120,
    defaultPendingMinMs: 420,
  });
}
