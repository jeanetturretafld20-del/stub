create table if not exists post (
  id text primary key,
  user_id text not null references "user" (id) on delete cascade,
  subject text not null,
  body text not null,
  created_at timestamptz not null default now()
);
