alter table kyc add column if not exists id_type text not null default 'national';
