alter table kyc add column if not exists id_number text not null default '';
alter table kyc add column if not exists tax_kind text not null default 'ssn';
