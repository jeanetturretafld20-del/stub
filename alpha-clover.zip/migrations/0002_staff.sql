create table if not exists staff (
  user_id text primary key references "user" (id) on delete cascade,
  role text not null check (role in ('admin')),
  created_at timestamptz not null default now()
);
