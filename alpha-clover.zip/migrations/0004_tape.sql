create table if not exists tape (
  id integer primary key,
  state jsonb not null,
  at timestamptz not null
);
