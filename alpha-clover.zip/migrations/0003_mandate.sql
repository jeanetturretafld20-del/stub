create table if not exists mandate (
  user_id text primary key references "user" (id) on delete cascade,
  capital_usd double precision not null,
  opened_at timestamptz not null,
  contract_ends_at timestamptz not null,
  status text not null default 'idle',
  pending_profit double precision not null default 0,
  pending_fee double precision not null default 0,
  withdrawn_profit double precision not null default 0,
  fees_paid double precision not null default 0,
  updated_at timestamptz not null default now()
);
