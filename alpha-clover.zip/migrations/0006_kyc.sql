create table if not exists kyc (
  user_id text primary key references "user" (id) on delete cascade,
  legal_name text not null,
  date_of_birth date not null,
  citizenship text not null,
  residence text not null,
  address text not null,
  city text not null,
  region text not null,
  postal text not null,
  phone text not null,
  employment text not null,
  source_of_funds text not null,
  tax_id text not null,
  pep boolean not null,
  filed_at timestamptz not null default now()
);
