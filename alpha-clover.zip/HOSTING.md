# Alpha Clover on a VPS or AWS

Node.js 22. Put the app behind HTTPS (nginx or Caddy). Sign-in cookies are marked secure, so a plain `http://` address will not keep a session.

## 1. Install and build

```bash
npm install
export VITE_AUTH_ENABLED=true
export BETTER_AUTH_SECRET="$(openssl rand -hex 32)"
export BETTER_AUTH_URL="https://your-domain.example"
export PGLITE_DATA_DIR="/var/lib/alpha-clover/pg"
mkdir -p "$PGLITE_DATA_DIR"
npm run build:vps
```

Keep `BETTER_AUTH_SECRET` and write it down. If it changes, every session is signed out.

`PGLITE_DATA_DIR` is the account database on one machine. It must survive restarts and must not be shared by two servers. For more than one machine, use Postgres instead and set `DATABASE_URL` to that connection string. Then you can leave `PGLITE_DATA_DIR` unset.

## 2. Run

```bash
export HOST=127.0.0.1
export PORT=3000
export VITE_AUTH_ENABLED=true
export BETTER_AUTH_SECRET="the-same-secret"
export BETTER_AUTH_URL="https://your-domain.example"
export PGLITE_DATA_DIR="/var/lib/alpha-clover/pg"
npm start
```

Point the proxy at port 3000. Example nginx site:

```nginx
server {
  listen 443 ssl;
  server_name your-domain.example;
  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-Proto https;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
  }
}
```

## 3. Confirmation letters

Outlook is only connected inside Grok. On your own server, set:

```bash
export RESEND_API_KEY="re_..."
export MAIL_FROM="Alpha Clover <letters@your-domain.example>"
```

The address in `MAIL_FROM` must be a domain you have verified at Resend. Without those two variables, the account is created and the letter does not leave.

## 4. Prices

Charts and desk quotes are read live from the public exchange feed. The server needs outbound HTTPS. No market-data key.
